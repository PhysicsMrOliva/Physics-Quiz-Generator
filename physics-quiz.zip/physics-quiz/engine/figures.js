/* =====================================================================
   engine/figures.js
   Reusable SVG drawings: ground, people, arrows, boxes, vehicles, graphs,
   and the QR code. Any unit can use these. Figures that only make sense
   for one unit can live in that unit's file instead.
   ===================================================================== */
"use strict";
/* ---------------- Drawing helpers (SVG) ---------------- */
function ground(x1, x2, y, rough) {
  if (rough) {
    let d = `M${x1} ${y}`;
    for (let x = x1; x < x2; x += 6) d += ` L${x + 3} ${y + (x % 12 === 0 ? 2.5 : -1.5)} L${x + 6} ${y}`;
    return `<path d="${d}" fill="none" stroke="#222" stroke-width="1.2"/>`;
  }
  let s = `<line x1="${x1}" y1="${y}" x2="${x2}" y2="${y}" stroke="#222" stroke-width="1.2"/>`;
  for (let x = x1 + 2; x < x2; x += 7) s += `<line x1="${x}" y1="${y}" x2="${x - 5}" y2="${y + 5}" stroke="#777" stroke-width=".8"/>`;
  return s;
}
function pusher(bx, gy) {
  return `<g stroke="#222" stroke-width="1.4" fill="none" stroke-linecap="round">
    <circle cx="${bx - 17}" cy="${gy - 46}" r="5.5" fill="#fff"/>
    <line x1="${bx - 19}" y1="${gy - 40}" x2="${bx - 24}" y2="${gy - 20}"/>
    <line x1="${bx - 24}" y1="${gy - 20}" x2="${bx - 36}" y2="${gy}"/>
    <line x1="${bx - 24}" y1="${gy - 20}" x2="${bx - 16}" y2="${gy}"/>
    <line x1="${bx - 20}" y1="${gy - 35}" x2="${bx}" y2="${gy - 32}"/>
    <line x1="${bx - 21}" y1="${gy - 31}" x2="${bx}" y2="${gy - 27}"/></g>`;
}
function puller(hx, hy, gy) {
  return `<g stroke="#222" stroke-width="1.4" fill="none" stroke-linecap="round">
    <circle cx="${hx + 15}" cy="${gy - 46}" r="5.5" fill="#fff"/>
    <line x1="${hx + 14}" y1="${gy - 40}" x2="${hx + 18}" y2="${gy - 20}"/>
    <line x1="${hx + 18}" y1="${gy - 20}" x2="${hx + 30}" y2="${gy}"/>
    <line x1="${hx + 18}" y1="${gy - 20}" x2="${hx + 8}" y2="${gy}"/>
    <line x1="${hx + 15}" y1="${gy - 35}" x2="${hx}" y2="${hy}"/></g>`;
}
function arrow(x1, y1, x2, y2, label, lx, ly) {
  const ang = Math.atan2(y2 - y1, x2 - x1), a = 6;
  const p1 = [x2 - a * Math.cos(ang - .45), y2 - a * Math.sin(ang - .45)], p2 = [x2 - a * Math.cos(ang + .45), y2 - a * Math.sin(ang + .45)];
  let s = `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#222" stroke-width="1.4"/>`;
  s += `<polygon points="${x2},${y2} ${p1[0]},${p1[1]} ${p2[0]},${p2[1]}" fill="#222"/>`;
  if (label) s += `<text x="${lx}" y="${ly}" font-family="Avenir Next,Segoe UI,Arial,sans-serif" font-size="10" fill="#222">${label}</text>`;
  return s;
}
function sceneSVG(kind, opts = {}) {
  const W = opts.w || 230, H = opts.h || 74, gy = H - 12;
  const bw = opts.bw || 38, bh = opts.bh || 36;
  let s = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${kind} diagram">`;
  s += ground(6, W - 6, gy, opts.rough);
  if (kind === "push") {
    const bx = 78;
    s += `<rect x="${bx}" y="${gy - bh}" width="${bw}" height="${bh}" fill="#e4e4e4" stroke="#222" stroke-width="1.2"/>`;
    s += pusher(bx, gy);
    s += arrow(bx + bw + 8, gy - bh / 2, bx + bw + 42, gy - bh / 2, "");
  } else if (kind === "sled") {
    const bx = opts.bx || 40;
    s += `<rect x="${bx}" y="${gy - 24}" width="${bw + 10}" height="16" fill="#e4e4e4" stroke="#222" stroke-width="1.2"/>`;
    s += `<path d="M${bx - 6} ${gy - 6} Q${bx - 10} ${gy} ${bx - 2} ${gy - 1} L${bx + bw + 14} ${gy - 1}" fill="none" stroke="#222" stroke-width="1.4"/>`;
    s += `<line x1="${bx + 6}" y1="${gy - 8}" x2="${bx + 6}" y2="${gy - 1}" stroke="#222"/><line x1="${bx + bw}" y1="${gy - 8}" x2="${bx + bw}" y2="${gy - 1}" stroke="#222"/>`;
    const ry = gy - 16, hx = bx + bw + 72;
    s += `<line x1="${bx + bw + 10}" y1="${ry}" x2="${hx}" y2="${ry}" stroke="#222" stroke-width="1.1"/>`;
    s += puller(hx, ry, gy);
  } else {
    const bx = opts.bx || 40;
    s += `<rect x="${bx}" y="${gy - bh}" width="${bw}" height="${bh}" fill="#e4e4e4" stroke="#222" stroke-width="1.2"/>`;
    const ry = gy - Math.min(bh * .55, 22), hx = bx + bw + (opts.rope || 80);
    s += `<line x1="${bx + bw}" y1="${ry}" x2="${hx}" y2="${ry}" stroke="#222" stroke-width="1.1"/>`;
    s += puller(hx, ry, gy);
  }
  if (opts.label) s += `<text x="4" y="12" font-family="Avenir Next,Segoe UI,Arial,sans-serif" font-size="10" fill="#333">${opts.label}</text>`;
  return s + "</svg>";
}
function forceSketchSVG() {
  const W = 210, H = 150, cx = 105, cy = 72, b = 34;
  let s = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Forces on the box">`;
  s += ground(20, 190, cy + b / 2, false);
  s += `<rect x="${cx - b / 2}" y="${cy - b / 2}" width="${b}" height="${b}" fill="#e4e4e4" stroke="#222" stroke-width="1.2"/>`;
  s += arrow(cx, cy - b / 2 - 4, cx, cy - b / 2 - 46, "N", cx + 6, cy - b / 2 - 38);
  s += arrow(cx, cy + b / 2 + 8, cx, cy + b / 2 + 50, "W", cx + 6, cy + b / 2 + 46);
  s += arrow(cx + b / 2 + 4, cy, cx + b / 2 + 50, cy, "A (see table)", cx + b / 2 + 6, cy - 6);
  s += arrow(cx - b / 2 - 4, cy + b / 2 - 4, cx - b / 2 - 40, cy + b / 2 - 4, "f", cx - b / 2 - 30, cy + b / 2 - 10);
  return s + "</svg>";
}
function forceTimeSVG(P, K, step, t1) {
  const W = 250, H = 172, L = 40, R = 8, T = 8, B = 30, pw = W - L - R, ph = H - T - B;
  const ymax = step * 10, tmax = 3.0;
  const X = t => L + pw * t / tmax, Y = f => T + ph * (1 - f / ymax);
  let s = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Applied force versus time graph" font-family="Avenir Next,Segoe UI,Arial,sans-serif">`;
  for (let i = 0; i <= 10; i++) {
    const y = Y(i * step);
    s += `<line x1="${L}" y1="${y}" x2="${L + pw}" y2="${y}" stroke="${i === 0 ? "#222" : "#c8c8c8"}" stroke-width="${i === 0 ? 1.2 : .7}"/>`;
    s += `<text x="${L - 5}" y="${y + 3.5}" font-size="9" text-anchor="end" fill="#222">${i * step}</text>`;
  }
  for (let i = 0; i <= 6; i++) {
    const t = i * 0.5, x = X(t);
    s += `<line x1="${x}" y1="${T}" x2="${x}" y2="${T + ph}" stroke="${i === 0 ? "#222" : "#e0e0e0"}" stroke-width="${i === 0 ? 1.2 : .6}"/>`;
    s += `<text x="${x}" y="${T + ph + 13}" font-size="9" text-anchor="middle" fill="#222">${t.toFixed(1)}</text>`;
  }
  s += `<text x="${L + pw / 2}" y="${H - 3}" font-size="10" text-anchor="middle" fill="#222">Time (s)</text>`;
  s += `<text transform="translate(11 ${T + ph / 2}) rotate(-90)" font-size="10" text-anchor="middle" fill="#222">Applied force (N)</text>`;
  s += `<polyline points="${X(0)},${Y(0)} ${X(t1)},${Y(P)} ${X(t1 + 0.07)},${Y(K)} ${X(tmax)},${Y(K)}" fill="none" stroke="#111" stroke-width="2"/>`;
  return s + "</svg>";
}
function qrSVG(text) {
  const q = qrcode(0, "M"); q.addData(text); q.make();
  const n = q.getModuleCount(); let d = "";
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) d += `M${c} ${r}h1v1h-1z`;
  return `<svg class="qrc" viewBox="-2 -2 ${n + 4} ${n + 4}" xmlns="http://www.w3.org/2000/svg" shape-rendering="crispEdges" role="img" aria-label="Page ID code"><rect x="-2" y="-2" width="${n + 4}" height="${n + 4}" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
}

/* ---- figures ---- */
const SVGF = `font-family="Avenir Next,Segoe UI,Arial,sans-serif"`;
function motionArrow(x, y, label = "v") { return arrow(x, y, x + 34, y, label, x + 12, y - 5); }
function bikeSVG(opts = {}) {
  const W = 170, H = 94, gy = H - 10;
  let s = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Bicyclist">`;
  s += ground(6, W - 6, gy, false);
  const r = 14, x1 = 48, x2 = 104, wy = gy - r;
  const seat = [x1 + 24, wy - 24], bar = [x2 - 4, wy - 30], sh = [x1 + 40, wy - 46];
  s += `<g stroke="#222" stroke-width="1.4" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="${x1}" cy="${wy}" r="${r}"/><circle cx="${x2}" cy="${wy}" r="${r}"/>
    <path d="M${x1} ${wy} L${x1 + 28} ${wy} L${seat[0]} ${seat[1]} L${x2 - 8} ${wy - 24} L${x2} ${wy} M${x1 + 28} ${wy} L${x2 - 8} ${wy - 24} M${x1} ${wy} L${seat[0]} ${seat[1]} M${x2 - 8} ${wy - 24} L${bar[0]} ${bar[1]} M${seat[0] - 5} ${seat[1]} h10"/>
    <path d="M${seat[0]} ${seat[1] - 2} L${sh[0]} ${sh[1]} L${bar[0]} ${bar[1]} M${seat[0]} ${seat[1] - 2} L${x1 + 36} ${wy - 12} L${x1 + 30} ${wy}"/>
    <circle cx="${sh[0] + 5}" cy="${sh[1] - 8}" r="5.5" fill="#fff"/></g>`;
  s += motionArrow(W - 50, 18, "v");
  if (opts.skid) s += `<path d="M${x2 + 14} ${gy - 1} h28 M${x1 - 40} ${gy - 1} h22" stroke="#555" stroke-width="2.4"/>`;
  return s + "</svg>";
}
function truckSVG(dir = "right") {
  const W = 240, H = 92, gy = H - 8;
  let s = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Box on a truck bed">`;
  s += ground(6, W - 6, gy, false);
  s += `<g stroke="#222" stroke-width="1.3">
    <rect x="22" y="${gy - 34}" width="132" height="8" fill="#e4e4e4"/>
    <rect x="22" y="${gy - 26}" width="178" height="12" fill="#f4f4f4"/>
    <path d="M154 ${gy - 26} V${gy - 62} H184 L200 ${gy - 42} V${gy - 26} Z" fill="#f4f4f4"/>
    <rect x="160" y="${gy - 56}" width="20" height="14" fill="#fff"/>
    <rect x="66" y="${gy - 62}" width="30" height="28" fill="#e4e4e4"/>
    <circle cx="52" cy="${gy - 10}" r="10" fill="#fff"/><circle cx="174" cy="${gy - 10}" r="10" fill="#fff"/></g>`;
  s += motionArrow(176, 12, "v");
  return s + "</svg>";
}
function tugSVG() {
  const W = 300, H = 74, gy = H - 12, bx = 132, bw = 36, bh = 34;
  let s = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Block pulled from both sides">`;
  s += ground(6, W - 6, gy, false);
  s += `<rect x="${bx}" y="${gy - bh}" width="${bw}" height="${bh}" fill="#e4e4e4" stroke="#222" stroke-width="1.2"/>`;
  const ry = gy - 20, hx = bx + bw + 74;
  const right = `<line x1="${bx + bw}" y1="${ry}" x2="${hx}" y2="${ry}" stroke="#222" stroke-width="1.1"/>${puller(hx, ry, gy)}`;
  s += right + `<g transform="translate(${2 * bx + bw} 0) scale(-1 1)">${right}</g>`;
  s += `<text x="${bx - 56}" y="${ry - 5}" ${SVGF} font-size="10">T<tspan baseline-shift="sub" font-size="7">L</tspan></text><text x="${bx + bw + 46}" y="${ry - 5}" ${SVGF} font-size="10">T<tspan baseline-shift="sub" font-size="7">R</tspan></text>`;
  return s + "</svg>";
}
function photoStripSVG(kind) {
  const W = 400, H = 62, gy = 52;
  const gaps = [0, 1, 2, 3, 4, 5].map(i => kind === "constant" ? 55 : kind === "speeding" ? 32 + i * 9.5 : 79.5 - i * 9.5);
  let s = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Photo strip of a pushed box">`;
  s += ground(4, W - 4, gy, false);
  let x = 26;
  for (let i = 0; i < 7; i++) {
    s += `<rect x="${x}" y="${gy - 15}" width="15" height="15" fill="#e4e4e4" stroke="#222" stroke-width="1"/>
      <g stroke="#222" stroke-width="1" fill="none"><circle cx="${x - 9}" cy="${gy - 26}" r="3.2" fill="#fff"/>
      <path d="M${x - 10} ${gy - 22} L${x - 13} ${gy - 11} L${x - 19} ${gy} M${x - 13} ${gy - 11} L${x - 8} ${gy} M${x - 11} ${gy - 19} L${x} ${gy - 16}"/></g>`;
    if (i < 6) x += gaps[i];
  }
  return s + "</svg>";
}
function miniGraphSVG(kind) {
  const W = 128, H = 96, L = 20, B = 18, T = 6, R = 6, pw = W - L - R, ph = H - T - B;
  const X = u => L + pw * u, Y = v => T + ph * (1 - v);
  const pts = {
    correct: [[0, 0], [.55, .8], [.56, .55], [1, .55]],
    nodrop: [[0, 0], [.55, .8], [1, .8]],
    linear: [[0, 0], [1, .95]],
    tozero: [[0, 0], [.55, .8], [.56, 0], [1, 0]],
  }[kind];
  return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Friction versus applied force graph">
    <line x1="${L}" y1="${T}" x2="${L}" y2="${T + ph}" stroke="#222"/><line x1="${L}" y1="${T + ph}" x2="${L + pw}" y2="${T + ph}" stroke="#222"/>
    <text transform="translate(12 ${T + ph / 2}) rotate(-90)" ${SVGF} font-size="8.5" text-anchor="middle">Friction</text>
    <text x="${L + pw / 2}" y="${H - 4}" ${SVGF} font-size="8.5" text-anchor="middle">Applied force</text>
    <polyline points="${pts.map(([u, v]) => `${X(u)},${Y(v)}`).join(" ")}" fill="none" stroke="#111" stroke-width="2"/></svg>`;
}
function vtGraphSVG(v0, tStop) {
  const W = 260, H = 172, L = 40, R = 8, T = 8, B = 30, pw = W - L - R, ph = H - T - B, vmax = 20, tmax = 8;
  const X = t => L + pw * t / tmax, Y = v => T + ph * (1 - v / vmax);
  let s = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Velocity versus time graph" ${SVGF}>`;
  for (let i = 0; i <= 10; i++) {
    const y = Y(i * 2);
    s += `<line x1="${L}" y1="${y}" x2="${L + pw}" y2="${y}" stroke="${i ? "#c8c8c8" : "#222"}" stroke-width="${i ? .7 : 1.2}"/><text x="${L - 5}" y="${y + 3.5}" font-size="9" text-anchor="end">${i * 2}</text>`;
  }
  for (let i = 0; i <= 16; i++) {
    const x = X(i / 2);
    s += `<line x1="${x}" y1="${T}" x2="${x}" y2="${T + ph}" stroke="${i ? "#e0e0e0" : "#222"}" stroke-width="${i ? .6 : 1.2}"/>`;
    if (i % 2 === 0) s += `<text x="${x}" y="${T + ph + 13}" font-size="9" text-anchor="middle">${i / 2}</text>`;
  }
  s += `<text x="${L + pw / 2}" y="${H - 3}" font-size="10" text-anchor="middle">Time (s)</text>`;
  s += `<text transform="translate(11 ${T + ph / 2}) rotate(-90)" font-size="10" text-anchor="middle">Velocity (m/s)</text>`;
  s += `<polyline points="${X(0)},${Y(v0)} ${X(tStop)},${Y(0)} ${X(tmax)},${Y(0)}" fill="none" stroke="#111" stroke-width="2"/>`;
  return s + "</svg>";
}

