/* =====================================================================
   engine/app.js
   The app: roster, blueprint panel, quiz assembly and pagination, printed
   and JSON answer keys, the preview window, and the filled-in sample.
   Nothing in here is specific to one unit.
   ===================================================================== */
"use strict";
/* ---------------- Roster ---------------- */
let roster = [];
function parseCSV(text) {
  const rows = []; let row = [], cell = "", q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
    else if (c === '"') q = true;
    else if (c === ",") { row.push(cell); cell = ""; }
    else if (c === "\n" || c === "\r") { if (c === "\r" && text[i + 1] === "\n") i++; row.push(cell); rows.push(row); row = []; cell = ""; }
    else cell += c;
  }
  if (cell !== "" || row.length) { row.push(cell); rows.push(row); }
  return rows.filter(r => r.some(c => c.trim() !== ""));
}
function rosterFromRows(rows) {
  const head = rows[0].map(h => h.trim().toLowerCase());
  const find = (...keys) => head.findIndex(h => keys.some(k => h.includes(k)));
  let gi = find("group", "table", "team"), si = find("seat"), fi = find("first"), li = find("last"), ni = head.findIndex(h => h === "name" || h === "student" || h === "full name");
  let data = rows.slice(1);
  if (gi < 0 && si < 0 && fi < 0 && ni < 0) { gi = 0; si = 1; ni = 2; data = rows; }
  const out = [];
  for (const r of data) {
    let group = gi >= 0 ? (r[gi] || "").trim() : "", seat = si >= 0 ? (r[si] || "").trim() : "";
    const m = seat.match(/^(\d+)\s*([A-Za-z])$/);
    if (m && !group) { group = m[1]; seat = m[2]; }
    let name = ni >= 0 ? (r[ni] || "").trim() : `${fi >= 0 ? (r[fi] || "").trim() : ""} ${li >= 0 ? (r[li] || "").trim() : ""}`.trim();
    if (!name) continue;
    if (ni >= 0 && name.includes(",")) { const [l, f] = name.split(",").map(x => x.trim()); if (f) name = `${f} ${l}`; }
    seat = seat.toUpperCase();
    out.push({ name, group: parseInt(group, 10) || 0, seat, seatIdx: seat ? seat.charCodeAt(0) - 65 : -1 });
  }
  out.sort((a, b) => a.group - b.group || a.seat.localeCompare(b.seat) || a.name.localeCompare(b.name));
  return out;
}
const SAMPLE = `Group,Seat,First,Last
1,A,Ava,Martinez
1,B,Liam,Chen
1,C,Sofia,Okafor
1,D,Noah,Patel
2,A,Mia,Johnson
2,B,Ethan,Nguyen
2,C,Isabella,Rossi
2,D,Lucas,Kim
3,A,Amara,Singh
3,B,Mateo,Garcia
3,C,Chloe,Dubois
3,D,Elijah,Brooks
4,A,Zoe,Haddad
4,B,Kai,Tanaka
4,C,Layla,Rahman
4,D,Owen,Fischer
5,A,Nora,Alvarez
5,B,Caleb,Wright
5,C,Priya,Iyer
5,D,Julian,Morales
6,A,Hana,Sato
6,B,Diego,Ramos
6,C,Grace,Liu
6,D,Isaac,Bennett
7,A,Leah,Cohen
7,B,Omar,Farouk
7,C,Ruby,Walsh
7,D,Felix,Novak`;
function setRoster(r, src) {
  roster = r;
  const groups = new Set(r.map(s => s.group)).size;
  document.getElementById("rosterStatus").textContent = r.length
    ? `${r.length} students in ${groups} group${groups === 1 ? "" : "s"} loaded from ${src}.`
    : `No students found in ${src}. Check that it has a Name or First/Last column.`;
}

/* ---------------- Blueprint UI ----------------
   A blueprint is a saved quiz or exam layout: which groups, how many of each, and
   settings. Unit quizzes, midterms and finals are all blueprints. */
function renderBlueprint() {
  document.getElementById("blueprint").innerHTML = QB.units.map(u => `<details class="unit" open data-unit="${u.id}">
    <summary><b>Unit ${u.number}: ${esc(u.title)}</b> <span class="ucount"></span></summary>
    <table class="bp">${u.groups.map(g => `<tr><td class="id">${g.id}</td>
      <td>${g.title}<span class="desc">${g.desc}</span><span class="desc lsn">+Physics ${lessonShort(g)} · about ${g.minutes} min</span><button type="button" class="pv" data-pv="${g.uid}" aria-label="Preview ${g.uid}">Preview</button></td><td class="t">Tier ${g.tier}</td>
      <td class="n"><input type="number" min="0" max="5" value="0" data-g="${g.uid}" aria-label="Questions from ${g.uid}"></td></tr>`).join("")}</table></details>`).join("");
}
function readBlueprint() {
  const bp = {};
  document.querySelectorAll("#blueprint input[data-g]").forEach(i => { const n = Math.max(0, Math.min(5, parseInt(i.value, 10) || 0)); if (n) bp[i.dataset.g] = n; });
  return bp;
}
const ptsCache = {};
function groupPoints(g) { // points for one question from the group (sampled once)
  if (ptsCache[g.uid] === undefined) { const q = g.gen(makeRng(`pts|${g.uid}`), g.variants[0]); ptsCache[g.uid] = q.spec.reduce((a, p) => a + ptsOf(p), 0); }
  return ptsCache[g.uid];
}
function currentBlueprint() {
  const items = Object.entries(readBlueprint()).map(([group, count]) => ({ group, count, version: QB.byUid[group].version }));
  return {
    format: QB.BLUEPRINT_FORMAT, name: document.getElementById("title").value.trim() || "Quiz",
    title: document.getElementById("title").value.trim() || "Quiz",
    pageBudget: parseInt(document.getElementById("pageBudget").value, 10) || QB.course.pageBudget,
    tolerancePct: parseFloat(document.getElementById("tol").value),
    workSpace: parseFloat(document.getElementById("work").value),
    items,
  };
}
function applyBlueprint(bp) {
  const missing = [];
  document.querySelectorAll("#blueprint input[data-g]").forEach(i => i.value = 0);
  for (const it of bp.items || []) {
    const inp = document.querySelector(`#blueprint input[data-g="${it.group}"]`);
    if (inp) inp.value = it.count; else missing.push(it.group);
  }
  if (bp.title) document.getElementById("title").value = bp.title;
  if (bp.pageBudget) document.getElementById("pageBudget").value = bp.pageBudget;
  if (bp.tolerancePct) document.getElementById("tol").value = String(bp.tolerancePct);
  if (bp.workSpace) document.getElementById("work").value = String(bp.workSpace);
  updateSummary();
  const changed = (bp.items || []).filter(it => QB.byUid[it.group] && it.version && it.version !== QB.byUid[it.group].version).map(it => it.group);
  const msg = [];
  if (missing.length) msg.push(`This blueprint uses groups that aren’t in the question bank: ${missing.join(", ")}.`);
  if (changed.length) msg.push(`These groups have changed since the blueprint was saved: ${changed.join(", ")}. New quizzes will use the current versions.`);
  document.getElementById("bpMsg").textContent = msg.join(" ");
}
function updateSummary() {
  const bp = readBlueprint();
  let n = 0, pts = 0, mins = 0;
  for (const [uid, c] of Object.entries(bp)) { const g = QB.byUid[uid]; n += c; pts += c * groupPoints(g); mins += c * g.minutes; }
  document.getElementById("bpSummary").textContent = n ? `${n} question${n === 1 ? "" : "s"} · ${pts} points · about ${mins} minutes` : "No questions selected yet.";
  document.querySelectorAll("#blueprint details.unit").forEach(d => {
    const c = [...d.querySelectorAll("input[data-g]")].reduce((a, i) => a + (parseInt(i.value, 10) || 0), 0);
    d.querySelector(".ucount").textContent = c ? `${c} selected` : "";
  });
}
function renderPresets() {
  const sel = document.getElementById("preset");
  sel.innerHTML = `<option value="">Choose a saved blueprint…</option>` + QB.course.presets.map((p, i) => `<option value="${i}">${esc(p.name)}</option>`).join("");
}

/* ---------------- Assembly ---------------- */
function buildQuestions(student, S) {
  const qs = [], sKey = student.name.trim().toLowerCase();
  for (const g of QB.groups) {
    const count = S.bp[g.uid] || 0;
    if (!count) continue;
    const trng = makeRng(`${S.quizId}|table|${student.group}|${g.uid}`);
    const order = g.arrange ? g.arrange(trng) : trng.shuffle(g.variants.slice());
    const si = student.seatIdx >= 0 ? student.seatIdx : cyrb53(sKey) % order.length;
    for (let k = 0; k < count; k++) {
      const variant = order[(si * count + k) % order.length];
      const q = g.gen(makeRng(`${S.quizId}|${sKey}|${g.uid}|${k}`), variant);
      q.pts = q.spec.reduce((a, p) => a + ptsOf(p), 0);
      Object.assign(q, { gid: g.uid, group: g, tier: g.tier, variant });
      qs.push(q);
    }
  }
  return qs;
}
function quizCode(S, st) {
  let h = cyrb53(`${S.quizId}|${st.name.trim().toLowerCase()}`), s = "";
  for (let i = 0; i < 5; i++) { s += CODE_ABC[h % CODE_ABC.length]; h = Math.floor(h / CODE_ABC.length); }
  return s;
}
function el(html) { const d = document.createElement("div"); d.innerHTML = html.trim(); return d.firstElementChild; }

let currentWork = 1;
function paginate(stage, items, makeHeader, fill) {
  const pages = [];
  let body;
  const newPage = (idx = pages.length) => {
    const page = document.createElement("div"); page.className = "page"; page.style.setProperty("--work", currentWork);
    const h = makeHeader(idx); if (h) page.appendChild(h);
    body = document.createElement("div"); body.className = "page-body"; page.appendChild(body);
    const f = document.createElement("div"); f.className = "page-foot"; page.appendChild(f);
    stage.appendChild(page); pages.push(page);
  };
  let tooTall = false;
  const over = () => body.scrollHeight > body.clientHeight + 1;
  if (!fill) {
    newPage();
    for (const it of items) {
      body.appendChild(it);
      if (over() && body.children.length > 1) { body.removeChild(it); newPage(); body.appendChild(it); }
      if (over()) tooTall = true;
    }
  } else { // fewest pages; among equal page counts, keep the original question order
    newPage();
    const cap0 = body.clientHeight;
    const hs = items.map(it => { body.appendChild(it); const h = it.offsetHeight + 6; body.removeChild(it); return h; });
    stage.removeChild(pages.pop());
    newPage(1); const capOther = body.clientHeight; stage.removeChild(pages.pop());
    const caps = n => n === 0 ? cap0 : capOther;
    const packCount = order => {
      let pg = 0, used = 0;
      for (const i of order) { if (used && used + hs[i] > caps(pg) + 6) { pg++; used = 0; } used += hs[i]; }
      return pg + 1;
    };
    let best = items.map((_, i) => i), bestN = packCount(best);
    if (items.length <= 7 && bestN > 1) {
      const perm = (arr, k) => {
        if (k === arr.length) { const n = packCount(arr); if (n < bestN) { bestN = n; best = arr.slice(); } return; }
        for (let i = k; i < arr.length; i++) { [arr[k], arr[i]] = [arr[i], arr[k]]; perm(arr, k + 1); [arr[k], arr[i]] = [arr[i], arr[k]]; }
      };
      perm(items.map((_, i) => i), 0);
    }
    newPage();
    for (const i of best) {
      body.appendChild(items[i]);
      if (over() && body.children.length > 1) { body.removeChild(items[i]); newPage(); body.appendChild(items[i]); }
      if (over()) tooTall = true;
    }
  }
  return { pages, tooTall };
}

let lastKey = null;
function generate() {
  if (!roster.length) { document.getElementById("rosterStatus").textContent = "Load a seating chart first."; return; }
  const S = {
    title: document.getElementById("title").value.trim() || "Quiz",
    quizId: document.getElementById("quizId").value.trim() || "Q",
    date: document.getElementById("date").value,
    tol: parseFloat(document.getElementById("tol").value) / 100,
    bp: readBlueprint(),
    pageBudget: parseInt(document.getElementById("pageBudget").value, 10) || QB.course.pageBudget,
    blueprint: currentBlueprint(),
  };
  if (!Object.keys(S.bp).length) { document.getElementById("warn").textContent = "Choose at least one question group first."; return; }
  currentWork = parseFloat(document.getElementById("work").value);
  const qStage = document.getElementById("quizStage"), kStage = document.getElementById("keyStage");
  qStage.innerHTML = ""; kStage.innerHTML = "";
  const wasKey = !kStage.hidden; qStage.hidden = false; kStage.hidden = false; // must be visible to measure
  document.getElementById("empty").style.display = "none";
  const dateTxt = S.date ? new Date(S.date + "T12:00").toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }) : "";
  let totalPages = 0; const over = [], tall = [], keyItems = [], keyStudents = [], codes = new Map(), names = new Map();
  for (const st of roster) {
    const qs = buildQuestions(st, S);
    if (!qs.length) continue;
    const total = qs.reduce((a, q) => a + q.pts, 0), code = quizCode(S, st);
    codes.set(code, (codes.get(code) || []).concat(st.name));
    names.set(st.name.toLowerCase(), (names.get(st.name.toLowerCase()) || 0) + 1);
    const seatTxt = st.group ? `${st.group}${st.seat}` : st.seat || "—";
    const items = qs.map((q, i) => el(`<div class="q" data-i="${i}"><div class="gut"><b class="qnum"></b><small>${q.pts} pts</small><i>${q.gid}</i></div>${q.html}</div>`));
    const header = n => n === 0
      ? el(`<div class="qhead"><div class="title"><b>${esc(S.title)}</b></div>
          <div class="who"><div><small>Name</small>${esc(st.name)}</div><div><small>Seat</small>${esc(seatTxt)}</div><div><small>Date</small>${esc(dateTxt)}</div><div><small>Score</small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/ ${total}</div></div>
          <div class="instr">Show all work: a free-body diagram, the given and unknown values, the equation, and your substitution. Report answers to ${SF()} significant figures, with units in the Units box. Use g = 9.81 m/s². Mark boxes with an X.</div></div>`)
      : el(`<div class="qhead2"><span>${esc(st.name)}, seat ${esc(seatTxt)}</span><span>${esc(S.title)}</span></div>`);
    const { pages, tooTall } = paginate(qStage, items, header, true);
    const pageOf = new Map();
    pages.forEach((pg, pi) => pg.querySelectorAll(".q").forEach(q => pageOf.set(+q.dataset.i, pi + 1)));
    const placed = pages.flatMap(pg => [...pg.querySelectorAll(".q")]);
    placed.forEach((q, n) => q.querySelectorAll(".qnum").forEach(s => s.textContent = n + 1));
    const ordered = placed.map(q => qs[+q.dataset.i]);
    const nContent = pages.length;
    pages.forEach((p, i) => {
      p.insertAdjacentHTML("beforeend", qrSVG(`PQ1|${S.quizId}|${code}|${i + 1}/${nContent}`));
      p.querySelector(".page-foot").innerHTML = `<span>Quiz code <b>${code}</b></span><span>Page ${i + 1} of ${nContent}</span>`;
    });
    if (nContent % 2) {
      qStage.insertAdjacentHTML("beforeend", `<div class="page blank"><div class="blanknote">This page is intentionally blank.</div>${qrSVG(`PQ1|${S.quizId}|${code}|blank`)}<div class="page-foot"><span>Quiz code <b>${code}</b></span><span>Back of page ${nContent}</span></div></div>`);
    }
    if (tooTall) tall.push(st.name);
    if (nContent > S.pageBudget) over.push(`${st.name} (${nContent})`);
    totalPages += nContent + (nContent % 2);
    keyItems.push(keyBlock(st, seatTxt, code, total, ordered, S));
    keyStudents.push(studentKeyJSON(st, seatTxt, code, total, ordered, placed.map(q => pageOf.get(+q.dataset.i)), nContent, S));
  }
  paginate(kStage, keyItems, () => el(`<div class="khead"><b>Answer key: ${esc(S.title)}</b><span>Quiz ID ${esc(S.quizId)}, tolerance ±${Math.round(S.tol * 100)}%</span></div>`), false)
    .pages.forEach((p, i, a) => p.querySelector(".page-foot").innerHTML = `<span>Answer key ${esc(S.quizId)}</span><span>Page ${i + 1} of ${a.length}</span>`);
  lastKey = keyJSON(S, keyStudents);
  document.getElementById("dlKey").disabled = false;
  const scope = document.getElementById("keyScope"); scope.disabled = false;
  scope.innerHTML = `<option value="all">All groups</option>` + [...new Set(keyStudents.map(s => s.group).filter(Boolean))].map(g => `<option value="${g}">Group ${g}</option>`).join("");
  setView(wasKey ? "key" : "quiz");
  document.getElementById("summary").textContent = `${keyStudents.length} quizzes, ${totalPages} printed pages`;
  const w = [];
  if (over.length) w.push(`These quizzes run longer than the ${S.pageBudget}-page budget: ${over.join(", ")}. Try Compact work space or fewer questions.`);
  if (tall.length) w.push(`A single question is taller than a page for ${tall.length} student(s); switch to Compact work space.`);
  const dupN = [...names].filter(([, c]) => c > 1).map(([n]) => n);
  if (dupN.length) w.push(`Duplicate names in the roster (${dupN.join(", ")}) get identical quizzes and codes. Add a middle initial to tell them apart.`);
  const dupC = [...codes].filter(([, v]) => v.length > 1);
  if (dupC.length) w.push(`Two students share a quiz code (${dupC.map(([c, v]) => `${c}: ${v.join(" & ")}`).join("; ")}). Change the Quiz ID slightly to fix this.`);
  document.getElementById("warn").textContent = w.join(" ");
}

/* ---------------- Printed key ---------------- */
function keyRows(q, n, tol) {
  const out = [];
  for (const p of q.spec) {
    const id = `${n}${p.tag}`;
    if (p.type === "num") out.push([`${id} ${p.prompt}${p.note ? ` <small style="color:#666">(${p.note})</small>` : ""}`, `${fmt3(p.value)}${p.unit ? " " + p.unit : ""}`, rangeText(p.value, tol), ptsOf(p)]);
    else if (p.type === "choice") out.push([`${id} ${p.prompt}`, Array.isArray(p.answer) ? p.answer.join(" <i>and</i> ") : p.answer, "", ptsOf(p)]);
    else if (p.type === "fbd") out.push([`${id} FBD: ${p.forces.map(f => `${(f.label || f.symbol.split(" ")[0])} ${f.direction}`).join(", ")}`, `${p.forces.length} forces`, "", ptsOf(p)]);
    else if (p.type === "trow") { const c = p.cells; out.push({ row: `${id} T<sub>L</sub> = ${fmt3(p.TL)} N: <b>${c.slides}</b>, f = <b>${fmt3(c.friction)} N ${c.friction_direction.toLowerCase()}</b>, |F<sub>net</sub>| = <b>${fmt3(c.net_force)} N</b> <span style="color:#666">(f ${c.friction ? rangeText(c.friction, tol) : "0"}; F ${c.net_force ? rangeText(c.net_force, tol) : "0"})</span>`, pts: ptsOf(p) }); }
    else if (p.type === "gu") out.push([`${n}gu Given &amp; unknown`, "✓", "", ptsOf(p)]);
    else if (p.type === "explanation") out.push([`${id} Explanation`, p.model, "", ptsOf(p)]);
    else if (p.type === "row") out.push({ row: `${id} A = ${fmt3(p.A)} N: <b>${p.slides ? "slides" : "no slide"}</b>, f = <b>${fmt3(p.f)} N</b>, |F<sub>net</sub>| = <b>${fmt3(p.net)} N</b> <span style="color:#666">(${p.net ? rangeText(p.net, tol) : "0"})</span>`, pts: ptsOf(p) });
  }
  return out;
}
function keyBlock(st, seatTxt, code, total, qs, S) {
  let html = `<div class="kblock"><h4>${esc(st.name)} <span>Seat ${esc(seatTxt)}, code ${code}, ${total} pts</span></h4><div class="kcols">`;
  qs.forEach((q, i) => {
    html += `<div class="kq"><div class="kt">Q${i + 1}. ${q.gid} <small>${q.summary}</small></div><table class="kt"><colgroup><col style="width:42%"><col style="width:27%"><col style="width:24%"><col style="width:7%"></colgroup>`;
    for (const r of keyRows(q, i + 1, S.tol)) {
      if (r.row) html += `<tr><td colspan="3">${r.row}</td><td class="pt">${r.pts}</td></tr>`;
      else html += `<tr><td>${r[0]}</td><td class="v">${r[1]}</td><td class="r">${r[2]}</td><td class="pt">${r[3]}</td></tr>`;
    }
    html += `</table></div>`;
  });
  return el(html + "</div></div>");
}

/* ---------------- JSON grading key ---------------- */
function partJSON(p, n, tol) {
  const id = `Q${n}${p.tag}`, ref = s => s.replace(/\{(\w+)\}/g, (_, t) => `Q${n}${t}`);
  const deps = (p.deps || []).map(t => `Q${n}${t}`);
  switch (p.type) {
    case "num": return { id, printed_tag: `${n}${p.tag}`, type: "numeric", prompt: plain(p.prompt), expected: r4(p.value), expected_3sf: plain(fmt3(p.value)),
      unit: p.unit.replace("²", "^2"), accept_range: accept(p.value, tol), expr: ref(p.expr), depends_on: deps, ...(p.note ? { note: plain(p.note) } : {}), points: p.pts };
    case "choice": return { id, printed_tag: `${n}${p.tag}`, type: p.multi ? "choice_multiple" : "choice", prompt: plain(p.prompt), options: p.options.map(plain), expected: Array.isArray(p.answer) ? p.answer.map(plain) : plain(p.answer), ...(p.multi ? { select: p.multi } : {}),
      ...(p.expr ? { expr: ref(p.expr), depends_on: deps } : {}), points: p.pts };
    case "fbd": return { id, printed_tag: `${n}${p.tag}`, type: "fbd", prompt: plain(p.prompt), required_forces: p.forces, points: p.pts };
    case "gu": return { id: `Q${n}gu`, printed_tag: `${n}gu`, type: "given_unknown", prompt: p.prompt, points: p.pts };
    case "explanation": return { id, printed_tag: `${n}${p.tag}`, type: "explanation", prompt: plain(p.prompt), model_answer: p.model, key_ideas: p.ideas, points: p.pts };
    case "trow": return { id, printed_tag: `${n}${p.tag}`, type: "table_row_directions", left_tension_N: p.TL,
      expected: { slides: p.cells.slides, friction_N: r4(p.cells.friction), friction_direction: p.cells.friction_direction, net_force_N: r4(p.cells.net_force) },
      accept_range: { friction_N: accept(p.cells.friction, tol), net_force_N: accept(p.cells.net_force, tol) },
      expr: Object.fromEntries(Object.entries(p.expr).map(([k, v]) => [k, ref(v)])), depends_on: deps, points: p.pts };
    case "row": return { id, printed_tag: `${n}${p.tag}`, type: "table_row", applied_force_N: p.A,
      expected: { slides: p.slides ? "Yes" : "No", friction_N: r4(p.f), net_force_N: r4(p.net) },
      accept_range: { friction_N: accept(p.f, tol), net_force_N: accept(p.net, tol) },
      expr: Object.fromEntries(Object.entries(p.expr).map(([k, v]) => [k, ref(v)])), depends_on: deps, points: p.pts };
  }
}
function studentKeyJSON(st, seatTxt, code, total, qs, pages, nContent, S) {
  return {
    code, name: st.name, group: st.group || null, seat: st.seat || null, seat_label: seatTxt,
    content_pages: nContent, printed_pages: nContent + (nContent % 2), total_points: total,
    questions: qs.map((q, i) => ({
      number: i + 1, id: `Q${i + 1}`, group: q.gid, group_version: q.group.version, unit: `Unit ${q.group.unit.number}: ${q.group.unit.title}`,
      tier: q.tier, objective: q.group.objective, physics_plus_lessons: (q.group.lessons || []).map(l => `${l[0]} ${l[1]}`), variant: q.variant, page: pages[i], points: q.pts,
      statement: plain(q.statement), givens: q.givens, parts: q.spec.map(p => partJSON(p, i + 1, S.tol)),
    })),
  };
}
function keyJSON(S, students) {
  return {
    format: KEY_FORMAT,
    quiz: { id: S.quizId, title: S.title, date: S.date || null, generated: new Date().toISOString(), course: QB.course.name, g: G, sig_figs: SF(), tolerance_pct: Math.round(S.tol * 100),
      engine_version: QB.ENGINE_VERSION, units: Object.fromEntries(QB.units.map(u => [u.id, u.version])), blueprint: S.blueprint },
    conventions: {
      student_id: "Each page footer prints 'Quiz code XXXXX' and 'Page i of n'. The code uses only the letters ACDEFHJKMNPRTUVWXY and digits 3479.",
      qr_code: "Top-right QR on every page encodes PQ1|<quiz id>|<code>|<page>/<content pages>, or ...|blank on the padding page.",
      group_ids: "Group ids are <unit>-<group>, e.g. U7-D2 is Unit 7, group D2. group_version identifies the generator version used.",
      part_ids: "Part id Q<question number><tag>. The answer cell shows the printed_tag in small gray text, e.g. '2c'. 'gu' is the Given/Unknown box, 'a' is usually the free-body diagram, 'd1'...'d5' are table rows.",
      expr: "expr gives how a value is computed from givens (by symbol) and earlier parts (by part id). Use it for error carried forward: substitute the student's own values for the parts in depends_on.",
      points: "points lists each scoring criterion and its value. work = correct equation AND substitution shown; answer = value within accept_range (or consistent with carried-forward values), 3 significant figures, correct units.",
    },
    students,
  };
}

/* ---------------- Preview ---------------- */
const PV = { g: null, variant: null, seed: 1 };
function openPreview(id) {
  const g = QB.byUid[id];
  PV.g = g; PV.variant = g.variants[0]; PV.seed = 1;
  document.getElementById("pvTitle").textContent = `${g.uid}: ${g.title}`;
  document.getElementById("pvSub").textContent = `Unit ${g.unit.number}: ${g.unit.title}. Tier ${g.tier}, about ${g.minutes} minutes. Objective: ${g.objective}${g.lessons ? ` +Physics lessons: ${lessonLong(g)}.` : ""} ${g.variants.length} versions; students at the same table get different ones.`;
  document.getElementById("pvVars").innerHTML = g.variants.map(v => `<button type="button" data-v="${v}" aria-pressed="${v === PV.variant}">${(g.vlabels && g.vlabels[v]) || v}</button>`).join("");
  renderPreview();
  const d = document.getElementById("pvDlg");
  if (!d.open) d.showModal();
}
function renderPreview() {
  const g = PV.g, body = document.getElementById("pvBody");
  document.querySelectorAll("#pvVars button").forEach(b => b.setAttribute("aria-pressed", b.dataset.v === PV.variant));
  const q = g.gen(makeRng(`preview|${g.uid}|${PV.variant}|${PV.seed}`), PV.variant);
  q.pts = q.spec.reduce((a, p) => a + ptsOf(p), 0); q.gid = g.uid;
  const tol = parseFloat(document.getElementById("tol").value) / 100;
  const work = parseFloat(document.getElementById("work").value);
  let html = `<div class="page paper-preview" style="--work:${work}"><div class="q"><div class="gut"><b class="qnum">1</b><small>${q.pts} pts</small><i>${g.uid}</i></div>${q.html}</div></div>`;
  if (document.getElementById("pvAns").checked) {
    let k = `<div class="pv-key"><div class="kblock"><h4>Answers <span>${q.summary}</span></h4><table class="kt"><colgroup><col style="width:46%"><col style="width:24%"><col style="width:23%"><col style="width:7%"></colgroup>`;
    for (const r of keyRows(q, 1, tol)) {
      if (r.row) k += `<tr><td colspan="3">${r.row}</td><td class="pt">${r.pts}</td></tr>`;
      else k += `<tr><td>${r[0]}</td><td class="v">${r[1]}</td><td class="r">${r[2]}</td><td class="pt">${r[3]}</td></tr>`;
    }
    html += k + `</table></div></div>`;
  }
  body.innerHTML = html;
  body.querySelectorAll(".qnum").forEach(s => s.textContent = 1);
  if (document.getElementById("pvFill").checked) fillSample(body.querySelector(".q"), q);
}

/* Write a correct student response onto the previewed question */
const symHTML = k => k.replace(/^mu_(\w+)$/, "μ<sub>$1</sub>").replace(/^([A-Za-z])_(\w+)$/, "$1<sub>$2</sub>");
function subText(p, q) {
  if (p.expr === "0") return "";
  if (/^\w+$/.test(p.expr) && q.givens[p.expr]) return q.givens[p.expr].note ? "read from graph" : "";
  let out = p.expr;
  for (const k of Object.keys(q.givens).sort((a, b) => b.length - a.length))
    out = out.replace(new RegExp(`\\b${k}\\b`, "g"), fmt3(q.givens[k].value));
  out = out.replace(/\{(\w+)\}/g, (_, t) => fmt3(q.spec.find(x => x.tag === t).value));
  return out.replace(/\*/g, "×").replace(/ - /g, " − ") + " =";
}
function fbdSketch(forces) {
  const c = "#1d4ed8", W = 200, H = 108, cx = 100, cy = 56;
  const ar = (x1, y1, x2, y2) => { const a = Math.atan2(y2 - y1, x2 - x1); return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${c}" stroke-width="1.6"/><polygon points="${x2},${y2} ${x2 - 7 * Math.cos(a - .4)},${y2 - 7 * Math.sin(a - .4)} ${x2 - 7 * Math.cos(a + .4)},${y2 - 7 * Math.sin(a + .4)}" fill="${c}"/>`; };
  const t = (x, y, s) => `<text x="${x}" y="${y}" font-family="Bradley Hand,Segoe Print,Comic Sans MS,cursive" font-size="12" fill="${c}">${s.replace(/^([A-Za-z])_(\w+)$/, "$1<tspan baseline-shift='sub' font-size='8'>$2</tspan>")}</text>`;
  let out = `<rect x="${cx - 9}" y="${cy - 9}" width="18" height="18" fill="none" stroke="${c}" stroke-width="1.3"/>`;
  const seen = {};
  for (const f of forces) {
    const lab = f.label || f.symbol.split(" ")[0], same = forces.filter(x => x.direction === f.direction).length;
    const i = seen[f.direction] = (seen[f.direction] ?? -1) + 1, off = same > 1 ? (i - (same - 1) / 2) * 12 : 0;
    if (f.direction === "up") out += ar(cx + off, cy - 9, cx + off, cy - 46) + t(cx + off + 5, cy - 36, lab);
    if (f.direction === "down") out += ar(cx + off, cy + 9, cx + off, cy + 46) + t(cx + off + 5, cy + 42, lab);
    if (f.direction === "right") out += ar(cx + 9, cy + off, cx + 58, cy + off) + t(cx + 62, cy + off + 4, lab);
    if (f.direction === "left") out += ar(cx - 9, cy + off, cx - 52, cy + off) + t(cx - 64 - (lab.length > 1 ? 6 : 0), cy + off + 4, lab);
  }
  return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" style="position:absolute;left:50%;top:55%;transform:translate(-50%,-50%)">${out}</svg>`;
}
function fillSample(root, q) {
  const hw = (s, cls = "") => `<span class="hw ${cls}">${s}</span>`;
  const mark = (scope, ans) => { if (!scope) return; const want = [].concat(ans); scope.querySelectorAll(".opt").forEach(o => { if (want.includes(o.dataset.opt)) o.classList.add("on"); }); };
  for (const p of q.spec) {
    const row = root.querySelector(`[data-tag="${p.tag}"]`);
    if (p.type === "num" && row) {
      row.querySelector(".eq").innerHTML = hw(p.eq || "");
      row.querySelector(".sub").innerHTML = hw(subText(p, q));
      row.querySelector(".val").insertAdjacentHTML("beforeend", hw(fmt3(p.value), "v"));
      row.querySelector(".unit").innerHTML = hw(p.unit, "v");
    } else if (p.type === "choice") mark(row, p.answer);
    else if (p.type === "row" && row) {
      mark(row, p.slides ? "Yes" : "No");
      row.querySelector(".fr").innerHTML = hw(fmt3(p.f));
      row.querySelector(".fn").innerHTML = hw(fmt3(p.net));
    } else if (p.type === "trow" && row) {
      mark(row.querySelector(".c-s"), p.cells.slides); mark(row.querySelector(".c-d"), p.cells.friction_direction);
      row.querySelector(".c-f").innerHTML = hw(fmt3(p.cells.friction)); row.querySelector(".c-n").innerHTML = hw(fmt3(p.cells.net_force));
    } else if (p.type === "explanation") {
      const l = root.querySelector(`.lines[data-tag="${p.tag}"]`);
      if (l) l.insertAdjacentHTML("beforeend", hw(p.fill || `Friction depends on μ and N. ${p.ideas[0]}, but ${p.ideas[1].charAt(0).toLowerCase() + p.ideas[1].slice(1)}.`));
    } else if (p.type === "fbd") {
      const box = root.querySelector(".setup .fbd"); if (box) box.insertAdjacentHTML("beforeend", fbdSketch(p.forces));
    } else if (p.type === "gu") {
      const [gBox, uBox] = root.querySelectorAll(".setup .gu > div");
      const given = Object.entries(q.givens).filter(([, v]) => !v.note)
        .map(([k, v]) => `${symHTML(k)} = ${fmt3(v.value)}${v.unit ? " " + v.unit.replace("^2", "²") : ""}`).join(", ");
      const unk = q.spec.filter(x => x.type === "num" && x.eq).map(x => x.eq.split(" = ")[0]).join(", ");
      gBox.insertAdjacentHTML("beforeend", hw(given));
      uBox.insertAdjacentHTML("beforeend", hw(unk));
    }
  }
}
document.getElementById("blueprint").addEventListener("click", e => { const b = e.target.closest("[data-pv]"); if (b) openPreview(b.dataset.pv); });
document.getElementById("pvVars").addEventListener("click", e => { const b = e.target.closest("[data-v]"); if (b) { PV.variant = b.dataset.v; renderPreview(); } });
document.getElementById("pvNew").addEventListener("click", () => { PV.seed++; renderPreview(); });
document.getElementById("pvAns").addEventListener("change", renderPreview);
document.getElementById("pvFill").addEventListener("change", renderPreview);
document.getElementById("pvClose").addEventListener("click", () => document.getElementById("pvDlg").close());
document.getElementById("pvDlg").addEventListener("click", e => { if (e.target.id === "pvDlg") e.target.close(); });

/* ---------------- Wiring ---------------- */
(function init() {
  const c = QB.course;
  document.getElementById("tol").value = String(c.tolerancePct);
  document.getElementById("work").value = String(c.workSpace);
  document.getElementById("pageBudget").value = c.pageBudget;
  renderBlueprint(); renderPresets();
  if (c.presets.length) { applyBlueprint(c.presets[0]); document.getElementById("preset").value = "0"; }
  else updateSummary();
})();
document.getElementById("blueprint").addEventListener("input", updateSummary);
document.getElementById("preset").addEventListener("change", e => { if (e.target.value !== "") applyBlueprint(QB.course.presets[+e.target.value]); });
document.getElementById("bpSave").addEventListener("click", () => {
  const bp = currentBlueprint();
  if (!bp.items.length) { document.getElementById("bpMsg").textContent = "Choose at least one question group before saving."; return; }
  download(`${bp.title.replace(/[^\w.-]+/g, "_")}-blueprint.json`, JSON.stringify(bp, null, 2), "application/json");
});
document.getElementById("bpLoadBtn").addEventListener("click", () => document.getElementById("bpLoad").click());
document.getElementById("bpLoad").addEventListener("change", e => {
  const f = e.target.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    try { const bp = JSON.parse(r.result); if (bp.format !== QB.BLUEPRINT_FORMAT) throw new Error("not a blueprint"); applyBlueprint(bp); document.getElementById("preset").value = ""; }
    catch (err) { document.getElementById("bpMsg").textContent = `That file isn’t a quiz blueprint (${err.message}).`; }
    e.target.value = "";
  };
  r.readAsText(f);
});
document.getElementById("date").valueAsDate = new Date();
document.getElementById("csv").addEventListener("change", e => {
  const f = e.target.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = () => setRoster(rosterFromRows(parseCSV(r.result)), f.name);
  r.readAsText(f);
});
document.getElementById("sample").addEventListener("click", () => setRoster(rosterFromRows(parseCSV(SAMPLE)), "the sample roster"));
function download(name, text, type) {
  const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
document.getElementById("template").addEventListener("click", () => download("seating-chart-template.csv", "Group,Seat,First,Last\n1,A,,\n1,B,,\n1,C,,\n1,D,,\n", "text/csv"));
document.getElementById("dlKey").addEventListener("click", () => {
  if (!lastKey) return;
  const g = document.getElementById("keyScope").value;
  const out = g === "all" ? lastKey : { ...lastKey, students: lastKey.students.filter(s => String(s.group) === g) };
  download(`${lastKey.quiz.id.replace(/[^\w.-]+/g, "_")}-grading-key${g === "all" ? "" : "-group" + g}.json`, JSON.stringify(out), "application/json");
});
document.getElementById("gen").addEventListener("click", generate);
function setView(v) {
  document.getElementById("vQuiz").setAttribute("aria-pressed", v === "quiz");
  document.getElementById("vKey").setAttribute("aria-pressed", v === "key");
  document.getElementById("quizStage").hidden = v !== "quiz";
  document.getElementById("keyStage").hidden = v !== "key";
}
document.getElementById("vQuiz").addEventListener("click", () => setView("quiz"));
document.getElementById("vKey").addEventListener("click", () => setView("key"));
document.getElementById("print").addEventListener("click", () => window.print());
