/* =====================================================================
   engine/core.js
   Shared by every unit: the question registry, course settings, seeded
   randomness, number formatting, and the building blocks for parts
   (numeric rows, choices, free-body diagrams, explanations).
   Load order (see index.html): lib/qrcode.min.js, engine/core.js,
   engine/figures.js, course.js, units/*.js, engine/app.js
   ===================================================================== */
"use strict";

/* ---------------- Registry ---------------- */
const QB = {
  ENGINE_VERSION: "2.0.0",
  KEY_FORMAT: "physics-quiz-key/2",
  BLUEPRINT_FORMAT: "physics-quiz-blueprint/1",
  course: { name: "Physics", g: 9.81, sigFigs: 3, tolerancePct: 2, workSpace: 1, pageBudget: 2, presets: [] },
  units: [],      // in course order
  groups: [],     // every group from every unit, each with .uid ("U7-A1") and .unit
  byUid: {},
  setCourse(c) { Object.assign(this.course, c); G = this.course.g; },
  registerUnit(u) {
    for (const k of ["id", "number", "title", "version", "groups"]) if (u[k] === undefined) throw new Error(`Unit is missing "${k}"`);
    if (this.units.some(x => x.id === u.id)) throw new Error(`Unit ${u.id} is registered twice`);
    for (const g of u.groups) {
      g.uid = `${u.id}-${g.id}`;
      g.unit = u;
      if (this.byUid[g.uid]) throw new Error(`Duplicate group ${g.uid}`);
      this.byUid[g.uid] = g;
    }
    this.units.push(u);
    this.units.sort((a, b) => a.number - b.number);
    this.groups = this.units.flatMap(x => x.groups);
  },
};
let G = 9.81; // gravitational field strength; set from course.js through QB.setCourse
const KEY_FORMAT = QB.KEY_FORMAT;

/* ---------------- Seeded randomness ---------------- */
function cyrb53(str, seed = 0) {
  let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
  for (let i = 0; i < str.length; i++) {
    const ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return 4294967296 * (2097151 & h2) + (h1 >>> 0);
}
function makeRng(key) {
  let a = cyrb53(key) % 4294967296;
  const next = () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return {
    next,
    uni: (lo, hi) => lo + (hi - lo) * next(),
    int: (lo, hi) => Math.floor(lo + (hi - lo + 1) * next()),
    pick: arr => arr[Math.floor(next() * arr.length)],
    shuffle: arr => { for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(next() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; } return arr; }
  };
}

/* ---------------- Numbers & text ---------------- */
// The "3" in these names is historical: they use the course's significant figures (QB.course.sigFigs).
const SF = () => QB.course.sigFigs;
const sf3 = x => Number(Number(x).toPrecision(SF()));
const r4 = x => x === 0 ? 0 : Number(Number(x).toPrecision(SF() + 1));
function fmt3(x) {
  if (x === 0) return "0";
  const s = Number(x).toPrecision(SF());
  if (!/e/.test(s)) return s.replace("-", "−");
  const [m, e] = s.split("e");
  return `${m.replace("-", "−")} × 10<sup>${parseInt(e, 10)}</sup>`;
}
const accept = (v, tol) => v === 0 ? [0, 0] : [r4(Math.min(v * (1 - tol), v * (1 + tol))), r4(Math.max(v * (1 - tol), v * (1 + tol)))];
const rangeText = (v, tol) => v === 0 ? "exactly 0" : accept(v, tol).map(fmt3).join(" – ");
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const plain = h => String(h).replace(/<sub>(.*?)<\/sub>/g, "_$1").replace(/<sup>(.*?)<\/sup>/g, "^$1").replace(/<br\s*\/?>/g, " ")
  .replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/−/g, "-").replace(/\s+/g, " ").trim();
const MU_S = "μ<sub>s</sub>", MU_K = "μ<sub>k</sub>";
const CODE_ABC = "ACDEFHJKMNPRTUVWXY3479"; // no look-alike characters (0/O, 1/I/L, 2/Z, 5/S, 8/B, 6/G)

/* ---------------- Parts: one model drives the quiz page, the printed key and the JSON key ----------------
   Part types: num, choice, fbd, gu (given & unknown), explanation, row (table row).
   expr strings use given symbols and {tag} for another part of the same question (for error carried forward). */
const tagSpan = (t, cls = "") => `<span class="ctag ${cls}"><span class="qnum"></span>${t}</span>`;
const cbOpt = o => `<span class="opt" data-opt="${esc(o)}"><span class="cb"></span>${o}</span>`;
function num(tag, prompt, value, unit, expr, deps = [], note = "") { return { tag, type: "num", prompt, value, unit, expr, deps, note, pts: { work: 1, answer: 1 } }; }
function choice(tag, prompt, options, answer, expr = "", deps = []) { return { tag, type: "choice", prompt, options, answer, expr, deps, pts: { answer: 1 } }; }
function fbdPart(forces, when) { return { tag: "a", type: "fbd", prompt: `Free-body diagram ${when}`, forces, pts: { fbd: 2 } }; }
const GU = { tag: "gu", type: "gu", prompt: "Given and unknown values listed", pts: { work: 1 } };
const withEq = (spec, map) => { for (const p of spec) if (map[p.tag]) p.eq = map[p.tag]; return spec; };
const SUB = (a, b) => `${a}<sub>${b}</sub>`;
const ptsOf = p => Object.values(p.pts).reduce((a, b) => a + b, 0);

function setupBlock(fig) {
  return `<div class="setup${fig ? " withfig" : ""}"><div class="fbd"><span class="l">Free-body diagram</span>${tagSpan("a")}</div>
    <div class="gu"><div><span class="l">Given</span>${tagSpan("gu")}</div><div><span class="l">Unknown</span></div></div>${fig ? `<div class="sfig">${fig}</div>` : ""}</div>`;
}
function workTable(spec) {
  let rows = "";
  for (const p of spec) {
    if (p.type === "choice") {
      rows += `<tr class="ch" data-tag="${p.tag}"><td class="p"><b>(${p.tag})</b> ${p.prompt}</td><td colspan="4" class="choice">${tagSpan(p.tag)}&nbsp;&nbsp; ${p.options.map(cbOpt).join("")}<small>(mark one)</small></td></tr>`;
    } else if (p.type === "num") {
      rows += `<tr data-tag="${p.tag}"><td class="p"><b>(${p.tag})</b> ${p.prompt}</td><td class="eq"></td><td class="sub"></td><td class="val">${tagSpan(p.tag, "corner")}</td><td class="unit"></td></tr>`;
    }
  }
  return `<table class="work"><colgroup><col style="width:27%"><col style="width:19%"><col style="width:28%"><col style="width:16%"><col style="width:10%"></colgroup>
    <thead><tr><th>Find</th><th>Equation</th><th>Substitute &amp; solve</th><th>Value (${SF()} s.f.)</th><th>Units</th></tr></thead><tbody>${rows}</tbody></table>`;
}
const STD_FORCES = (applied) => [
  { force: "Weight", symbol: "W or mg", label: "W", direction: "down" },
  { force: "Normal force", symbol: "N", label: "N", direction: "up" },
  { force: applied, symbol: "F_A or T", label: /tension/i.test(applied) ? "T" : "F_A", direction: "right" },
  { force: "Friction", symbol: "f", label: "f", direction: "left" },
];

/* ---------------- Helpers for the newer groups ---------------- */
function mcBlock(p, layout = "col") {
  return `<div class="mc" data-tag="${p.tag}"><div class="mcq"><b>(${p.tag})</b> ${p.prompt} ${tagSpan(p.tag)}${p.multi ? ` <small class="sans" style="color:#888">(mark ${p.multi})</small>` : ""}</div>
    <div class="mco ${layout}">${p.options.map(cbOpt).join("")}</div></div>`;
}
function explainBlock(p, n = 2) {
  return `<div class="mc"><div class="mcq"><b>(${p.tag})</b> ${p.prompt} ${tagSpan(p.tag)}</div><div class="lines" data-tag="${p.tag}">${"<div></div>".repeat(n)}</div></div>`;
}
function choiceRows(spec) {
  return `<table class="cmp">${spec.map(p => `<tr data-tag="${p.tag}"><td>(${p.tag}) ${p.prompt}</td><td class="opts">${tagSpan(p.tag)}&nbsp; ${p.options.map(cbOpt).join("")}</td></tr>`).join("")}</table>`;
}
const explain = (tag, prompt, model, ideas, fill) => ({ tag, type: "explanation", prompt, model, ideas, fill, pts: { explanation: 2 } });
const multiChoice = (tag, prompt, options, answers) => ({ tag, type: "choice", prompt, options, answer: answers, multi: answers.length, pts: { answer: 1 } });
const FRC = (force, label, direction) => ({ force, symbol: label, label, direction });
const fmtK = k => ({ 0.5: "half", [1 / 3]: "one-third", 2: "twice", 3: "three times" }[k]);

const lessonShort = g => (g.lessons || []).map(l => l[0]).join(", ");
const lessonLong = g => (g.lessons || []).map(l => `${l[0]} ${l[1]} (${l[2]})`).join("; ");
