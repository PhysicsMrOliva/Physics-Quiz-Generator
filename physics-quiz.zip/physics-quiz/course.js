/* =====================================================================
   course.js: settings for the whole course, and saved blueprints.
   Every unit inherits these. Edit this file to change course-wide rules.
   ===================================================================== */
"use strict";
QB.setCourse({
  name: "Physics",
  g: 9.81,              // m/s², used by every unit
  sigFigs: 3,           // given values and required answers
  tolerancePct: 2,      // default answer tolerance (2–5 available in the app)
  workSpace: 1,         // 0.8 compact, 1 standard, 1.3 roomy
  pageBudget: 2,        // warn when a quiz runs longer than this
  // Authoring rules for every unit (for whoever writes new question groups):
  rules: [
    "Equations are on a separate reference sheet. Do not print equations in question text unless the teacher asks.",
    "Given values use the course's significant figures, and answers must be reported to the same.",
    "Every numeric part has a work point (equation and substitution) and an answer point (value, sig figs, units).",
  ],
  // Blueprints shown in the "Start from a saved blueprint" menu. Save more from the app
  // (Save button) and paste them here, or keep them as files in /blueprints.
  presets: [
    {
      format: "physics-quiz-blueprint/1", name: "Unit 7 quiz (standard)", title: "Unit 7 Quiz: Friction",
      pageBudget: 2, tolerancePct: 2, workSpace: 1,
      items: [
        { group: "U7-A1", count: 1, version: 1 }, { group: "U7-B2", count: 1, version: 1 },
        { group: "U7-C2", count: 1, version: 1 }, { group: "U7-D2", count: 1, version: 1 },
      ],
    },
    {
      format: "physics-quiz-blueprint/1", name: "Unit 7 quiz (challenge)", title: "Unit 7 Quiz: Friction (Challenge)",
      pageBudget: 2, tolerancePct: 2, workSpace: 1,
      items: [
        { group: "U7-B1", count: 1, version: 1 }, { group: "U7-D1", count: 1, version: 1 },
        { group: "U7-D3", count: 1, version: 1 },
      ],
    },
  ],
});
