/* =====================================================================
   units/_unit-template.js: starting point for a new unit.
   1. Copy this file to units/unit-NN-topic.js and add it to units/units.js.
   2. Write one gen function per question group (see unit-07-friction.js
      for complete examples of every part type).
   3. Open test.html and fix anything it flags before using the unit.
   This template is not loaded by the app.
   ===================================================================== */
(() => {
"use strict";

/* A gen function receives a seeded rng and a variant name, and returns:
   html       the question body (statement, figure, work table)
   statement  the problem text (plain text is derived for the grading key)
   givens     { symbol: { value, unit, note? } } for every given value
   spec       the parts, built with num(), choice(), fbdPart(), GU, explain(), multiChoice()
   summary    a short description for the printed key                         */
function genA1(rng, variant) {
  const m = sf3(rng.uni(2, 10));                     // given values use the course's sig figs
  const statement = `A ${fmt3(m)} kg cart … (no equations in question text)`;
  const spec = [
    fbdPart([FRC("Weight", "W", "down"), FRC("Normal force", "N", "up")], "of the cart"), GU,
    num("b", "Normal force, N", m * G, "N", "m * g"),  // expr powers error-carried-forward grading
  ];
  withEq(spec, { b: "N = mg" });                     // shown only in the filled-in preview
  const html = `<div class="qbody"><div class="qtext"><p>${statement}</p></div></div>
    <div class="inner">${setupBlock()}${workTable(spec)}</div>`;
  return { html, statement, givens: { m: { value: m, unit: "kg" }, g: { value: G, unit: "m/s^2" } }, spec, summary: variant };
}

const groups = [
  { id: "A1", tier: 1, version: 1, minutes: 5, def: 0,
    title: "Short title", desc: "One-line description",
    objective: "What students show they can do.",
    lessons: [["N.N", "+Physics lesson name", "#1, #2"]],
    variants: ["v1"], vlabels: { v1: "Version 1" }, gen: genA1 },
];

QB.registerUnit({ id: "UNN", number: 0, title: "Topic", version: "1.0", source: "+Physics Unit N", lessons: {}, groups });
})();
