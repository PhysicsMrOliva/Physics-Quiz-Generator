/* =====================================================================
   units/unit-07-friction.js   (+Physics Unit 7: Friction)
   Question bank for one unit. Everything is inside the function below,
   so names like genA1 cannot collide with other units.
   ===================================================================== */
(() => {
"use strict";
/* ---------------- Question groups ----------------
   Each group: id (unique within the unit), tier, title, desc, objective, minutes (estimated),
   version (bump whenever the generator changes what students see or the answers),
   def (default count), variants, gen, lessons: [+Physics lesson, name, problems used],
   vlabels (preview names), optional arrange (seat-balancing order), optional tags. */


/* ----- A1: compare cases ----- */
function genA1(rng, variant) {
  const [kind, big] = variant.split("-");
  let statement, figA, figB, ans, givens, ideas;
  if (kind === "mass") {
    const surf = rng.pick(["level floor", "level sidewalk", "level gym floor"]);
    const mSmall = sf3(rng.uni(10, 25)), mBig = sf3(mSmall * rng.uni(1.6, 2.6));
    const mA = big === "A" ? mBig : mSmall, mB = big === "A" ? mSmall : mBig;
    statement = `Two students each pull a box across the same ${surf} with a horizontal rope, and both boxes slide. The box in Case A has a mass of ${fmt3(mA)} kg, and the box in Case B has a mass of ${fmt3(mB)} kg. Both boxes are made of the same material.`;
    const sz = m => m === mBig ? { bw: 46, bh: 44 } : { bw: 30, bh: 28 };
    figA = sceneSVG("rope", { ...sz(mA), label: "Case A", rope: 70 });
    figB = sceneSVG("rope", { ...sz(mB), label: "Case B", rope: 70 });
    ans = { N: `Case ${big}`, mu: "Equal", f: `Case ${big}`, why: `Same μ; Case ${big} has larger N, so larger f.` };
    givens = { m_A: { value: mA, unit: "kg" }, m_B: { value: mB, unit: "kg" } };
    ideas = ["μ is the same because the surfaces and materials are the same", `N is larger in Case ${big} because that box has more mass (N = mg)`, "f = μN, so the larger N gives the larger friction"];
  } else {
    const m = sf3(rng.uni(12, 30)), roughA = big === "A";
    statement = `Two students each pull an identical ${fmt3(m)} kg box across a level floor with a horizontal rope, and both boxes slide. The floor in Case ${roughA ? "A" : "B"} is rough concrete; the floor in Case ${roughA ? "B" : "A"} is smooth tile.`;
    figA = sceneSVG("rope", { bw: 36, bh: 34, label: "Case A", rope: 70, rough: roughA });
    figB = sceneSVG("rope", { bw: 36, bh: 34, label: "Case B", rope: 70, rough: !roughA });
    ans = { N: "Equal", mu: `Case ${big}`, f: `Case ${big}`, why: `Same N; Case ${big} has larger μ, so larger f.` };
    givens = { m: { value: m, unit: "kg" } };
    ideas = ["N is the same because the boxes have equal mass", `μ is larger for the rough surface (Case ${big})`, "f = μN, so the larger μ gives the larger friction"];
  }
  const C = ["Case A", "Case B", "Equal"];
  const spec = [
    choice("a", "In which case is the <b>normal force</b> greater?", C, ans.N),
    choice("b", "In which case is the <b>coefficient of friction</b> greater?", C, ans.mu),
    choice("c", "In which case is the <b>friction force</b> greater?", C, ans.f),
    { tag: "d", type: "explanation", prompt: "Use the friction equation to justify your answer to (c).", model: ans.why, ideas, pts: { explanation: 2 } },
  ];
  const rows = spec.filter(p => p.type === "choice").map(p => `<tr data-tag="${p.tag}"><td>(${p.tag}) ${p.prompt}</td><td class="opts">${tagSpan(p.tag)}&nbsp; ${p.options.map(cbOpt).join("")}</td></tr>`).join("");
  const html = `<div class="qbody"><div class="qtext"><p>${statement}</p>
      <table class="cmp">${rows}</table>
      <p style="margin-top:8px">(d) Use the friction equation to justify your answer to (c). ${tagSpan("d")}</p>
      <div class="lines" data-tag="d"><div></div><div></div></div></div>
    <div class="fig">${figA}${figB}</div></div>`;
  return { html, statement, givens, spec, summary: kind === "mass" ? `different masses, Case ${big} heavier` : `different surfaces, Case ${big} rough` };
}

/* ----- B2: slide-or-not table ----- */
function genB2(rng, variant) {
  const m = sf3(rng.uni(20, 80));
  const mus = sf3(rng.uni(0.30, 0.70));
  const muk = sf3(mus * rng.uni(0.6, 0.85));
  const N = m * G, fs = mus * N, fk = muk * N;
  const nb = rng.int(2, 3), na = 5 - nb, forces = [];
  for (let i = 0; i < nb; i++) forces.push(sf3(fs * (0.35 + 0.55 * (i + rng.uni(.15, .85)) / nb)));
  for (let i = 0; i < na; i++) forces.push(sf3(fs * (1.08 + 0.6 * (i + rng.uni(.15, .85)) / na)));
  const obj = variant === "rope" ? "crate" : "box";
  const how = variant === "rope"
    ? `A student pulls on a ${fmt3(m)} kg crate resting on a level floor using a horizontal rope, slowly increasing the tension A.`
    : `A student pushes horizontally on a ${fmt3(m)} kg box resting on a level floor, slowly increasing her applied force A.`;
  const statement = `${how} The coefficient of static friction between the ${obj} and the floor is ${MU_S} = ${fmt3(mus)}, and the coefficient of kinetic friction is ${MU_K} = ${fmt3(muk)}. The force only increases. Neglect drag.`;
  const spec = [
    num("a", "Normal force, N", N, "N", "m * g"),
    num("b", "Maximum static friction, f<sub>s,max</sub>", fs, "N", "mu_s * {a}", ["a"]),
    num("c", "Kinetic friction, f<sub>k</sub>", fk, "N", "mu_k * {a}", ["a"]),
  ];
  withEq(spec, { a: "N = mg", b: `${SUB("f", "s,max")} = ${SUB("μ", "s")}N`, c: `${SUB("f", "k")} = ${SUB("μ", "k")}N` });
  let rows = "";
  forces.forEach((A, i) => {
    const slides = A > fs, f = slides ? fk : A, net = slides ? A - fk : 0, t = `d${i + 1}`;
    spec.push({ tag: t, type: "row", A, slides, f, net, deps: ["b", "c"],
      expr: { slides: "applied_force_N > {b}", friction: "slides ? {c} : applied_force_N", net_force: "slides ? applied_force_N - {c} : 0" },
      pts: { slides: 1, friction: 1, net_force: 1 } });
    rows += `<tr data-tag="${t}"><td>${tagSpan(t)}</td><td>${fmt3(A)}</td><td class="yn">${["Yes", "No"].map(cbOpt).join("")}</td><td class="blankcell fr"></td><td class="blankcell fn"></td></tr>`;
  });
  const html = `<div class="qbody"><div class="qtext"><p>${statement}</p>
      <p>Find (a)–(c), then complete the table (d1–d5) for each value of A.</p></div></div>
    <div class="inner">${workTable(spec)}
      <div class="pair"><table class="grid"><thead><tr><th>Row</th><th>A (N)</th><th>Slides?</th><th>Friction (N)</th><th>|F<sub>net</sub>| (N)</th></tr></thead><tbody>${rows}</tbody></table>
      <div class="fig">${forceSketchSVG()}</div></div></div>`;
  const givens = { m: { value: m, unit: "kg" }, mu_s: { value: mus, unit: "" }, mu_k: { value: muk, unit: "" }, g: { value: G, unit: "m/s^2" } };
  return { html, statement, givens, spec, summary: `${variant}, ${nb} below / ${na} above threshold` };
}

/* ----- C2: measure coefficients ----- */
function genC2(rng, variant) {
  if (variant === "graph") {
    const step = rng.pick([2, 5, 10]);
    const k = rng.int(6, 9), j = rng.int(Math.ceil(0.55 * k), k - 1);
    const P = k * step, K = j * step;
    const m = sf3(P / (rng.uni(0.35, 0.80) * G)), N = m * G;
    const t1 = sf3(rng.uni(1.0, 1.9));
    const statement = `A ${fmt3(m)} kg wooden block is at rest on a level table. A student pulls horizontally on the block with a force meter, gradually increasing the force. The block suddenly jolts forward, and then the student pulls it at a constant speed. The graph shows the applied force over time. Neglect drag.`;
    const spec = [
      fbdPart(STD_FORCES("Applied force (pull)"), "of the block while it moves at constant speed"), GU,
      num("b", "Maximum static friction, f<sub>s,max</sub>", P, "N", "F_peak", [], "read peak of graph"),
      num("c", "Normal force, N", N, "N", "m * g"),
      num("d", `Coefficient of static friction, ${MU_S}`, P / N, "", "{b} / {c}", ["b", "c"]),
      num("e", "Kinetic friction, f<sub>k</sub>", K, "N", "F_plateau", [], "read plateau of graph"),
      num("f", `Coefficient of kinetic friction, ${MU_K}`, K / N, "", "{e} / {c}", ["e", "c"]),
    ];
    withEq(spec, { b: `${SUB("f", "s,max")} = peak force`, c: "N = mg", d: `${SUB("μ", "s")} = ${SUB("f", "s,max")} / N`, e: `${SUB("f", "k")} = constant-speed force`, f: `${SUB("μ", "k")} = ${SUB("f", "k")} / N` });
    const html = `<div class="qbody"><div class="qtext"><p>${statement}</p>
        <p>(a) Draw a free-body diagram of the block while it moves at constant speed. Then find (b)–(f).</p></div></div>
      <div class="inner">${setupBlock(forceTimeSVG(P, K, step, t1))}${workTable(spec)}</div>`;
    const givens = { m: { value: m, unit: "kg" }, g: { value: G, unit: "m/s^2" },
      F_peak: { value: P, unit: "N", note: "peak of the graph, on a gridline" }, F_plateau: { value: K, unit: "N", note: "constant-speed level of the graph, on a gridline" } };
    return { html, statement, givens, spec, summary: `graph: peak ${P} N, plateau ${K} N` };
  }
  const obj = rng.pick(["crate", "box", "filing cabinet"]);
  const m = sf3(rng.uni(20, 80));
  const mus = rng.uni(0.35, 0.80);
  const F1 = sf3(mus * m * G), F2 = sf3(mus * rng.uni(0.6, 0.85) * m * G), N = m * G;
  const statement = `A student is measuring the coefficients of friction between a ${fmt3(m)} kg ${obj} and a level floor. She finds that the ${obj} starts to slide only when her horizontal push is greater than ${fmt3(F1)} N. Once it is moving, she can keep it sliding at a constant speed by pushing with ${fmt3(F2)} N. Neglect drag.`;
  const spec = [
    fbdPart(STD_FORCES("Applied force (push)"), `of the ${obj} just before it starts to slide`), GU,
    num("b", "Normal force, N", N, "N", "m * g"),
    num("c", "Friction just before it slides", F1, "N", "F_slip"),
    num("d", `Coefficient of static friction, ${MU_S}`, F1 / N, "", "{c} / {b}", ["b", "c"]),
    num("e", "Friction while sliding at constant speed", F2, "N", "F_const"),
    num("f", `Coefficient of kinetic friction, ${MU_K}`, F2 / N, "", "{e} / {b}", ["b", "e"]),
  ];
  withEq(spec, { b: "N = mg", c: `${SUB("f", "s,max")} = ${SUB("F", "push")}`, d: `${SUB("μ", "s")} = ${SUB("f", "s,max")} / N`, e: `${SUB("f", "k")} = ${SUB("F", "push")} (a = 0)`, f: `${SUB("μ", "k")} = ${SUB("f", "k")} / N` });
  const html = `<div class="qbody"><div class="qtext"><p>${statement}</p>
      <p>(a) Draw a free-body diagram of the ${obj} just before it starts to slide. Then find (b)–(f).</p></div></div>
    <div class="inner">${setupBlock()}${workTable(spec)}</div>`;
  const givens = { m: { value: m, unit: "kg" }, g: { value: G, unit: "m/s^2" }, F_slip: { value: F1, unit: "N" }, F_const: { value: F2, unit: "N" } };
  return { html, statement, givens, spec, summary: `threshold ${fmt3(F1)} N, constant speed ${fmt3(F2)} N` };
}

/* ----- D2: complete problem ----- */
function genD2(rng, variant) {
  const [ctx, regime] = variant.split("-");
  const C = {
    push: { m: [20, 80], mus: [0.35, 0.70], obj: "box", where: "floor", applied: "Applied force (push)",
      text: (m, F) => `A student pushes a ${m} kg box across a level floor with a horizontal force of ${F} N to the right.`,
      more: F2 => `Later, the student increases her push to ${F2} N.` },
    rope: { m: [20, 80], mus: [0.35, 0.70], obj: "crate", where: "floor", applied: "Tension (rope)",
      text: (m, F) => `A student pulls a ${m} kg crate across a level warehouse floor using a horizontal rope. The tension in the rope is ${F} N.`,
      more: F2 => `Later, the student increases the tension to ${F2} N.` },
    sled: { m: [15, 60], mus: [0.10, 0.30], obj: "sled", where: "snow", applied: "Tension (rope)",
      text: (m, F) => `A child pulls a ${m} kg loaded sled across level snow using a horizontal rope, applying a ${F} N force.`,
      more: F2 => `Later, the child increases the pull to ${F2} N.` },
  }[ctx];
  const m = sf3(rng.uni(...C.m)), mus = sf3(rng.uni(...C.mus)), muk = sf3(mus * rng.uni(0.6, 0.85));
  const N = m * G, fs = mus * N, fk = muk * N;
  let F, F2, spec;
  const head = [
    fbdPart(STD_FORCES(C.applied), ""), GU,
    num("b", "Normal force, N", N, "N", "m * g"),
    num("c", "Maximum static friction, f<sub>s,max</sub>", fs, "N", "mu_s * {b}", ["b"]),
  ];
  if (regime === "slide") {
    F = sf3(fs * rng.uni(1.15, 1.5));
    spec = head.concat([
      choice("d", `Does the ${C.obj} slide?`, ["Yes", "No"], "Yes", "F_A > {c}", ["c"]),
      num("e", `Friction on the ${C.obj}`, fk, "N", "mu_k * {b}", ["b"], "kinetic"),
      num("f", "Net force, |F<sub>net</sub>|", F - fk, "N", "F_A - {e}", ["e"]),
      num("g", `Acceleration of the ${C.obj}`, (F - fk) / m, "m/s²", "{f} / m", ["f"]),
    ]);
  } else {
    F = sf3(fs * rng.uni(0.45, 0.85));
    do { F2 = sf3(fs * rng.uni(1.15, 1.5)); } while (F2 === F);
    spec = head.concat([
      choice("d", `Does the ${C.obj} slide?`, ["Yes", "No"], "No", "F_A > {c}", ["c"]),
      num("e", `Friction on the ${C.obj}`, F, "N", "F_A", ["d"], "static, equals applied force"),
      num("f", "Net force, |F<sub>net</sub>|", 0, "N", "0", ["d"]),
      num("g", `Acceleration at the ${fmt3(F2)} N force`, (F2 - fk) / m, "m/s²", "(F_A2 - mu_k * {b}) / m", ["b"], `f<sub>k</sub> = ${fmt3(fk)} N, F<sub>net</sub> = ${fmt3(F2 - fk)} N`),
    ]);
  }
  withEq(spec, regime === "slide"
    ? { b: "N = mg", c: `${SUB("f", "s,max")} = ${SUB("μ", "s")}N`, e: `${SUB("f", "k")} = ${SUB("μ", "k")}N`, f: `${SUB("F", "net")} = ${SUB("F", "A")} − ${SUB("f", "k")}`, g: `a = ${SUB("F", "net")} / m` }
    : { b: "N = mg", c: `${SUB("f", "s,max")} = ${SUB("μ", "s")}N`, e: `f = ${SUB("F", "A")} (no slide)`, f: `${SUB("F", "net")} = 0`, g: `a = (${SUB("F", "A2")} − ${SUB("μ", "k")}N) / m` });
  spec[0].prompt = `Free-body diagram of the ${C.obj}${regime === "rest" ? ` while the ${fmt3(F)} N force acts` : ""}`;
  const statement = `${C.text(fmt3(m), fmt3(F))} The coefficient of static friction between the ${C.obj} and the ${C.where} is ${MU_S} = ${fmt3(mus)}, and the coefficient of kinetic friction is ${MU_K} = ${fmt3(muk)}. Neglect drag.${regime === "rest" ? " " + C.more(fmt3(F2)) : ""}`;
  const fig = sceneSVG(ctx, { w: 190, bw: 34, bh: 32, rope: 62 });
  const html = `<div class="qbody"><div class="qtext"><p>${statement}</p>
      <p>(a) Draw a free-body diagram of the ${C.obj}${regime === "rest" ? ` while the ${fmt3(F)} N force acts` : ""}. Then find (b)–(g).</p></div>
      <div class="fig">${fig}</div></div>
    <div class="inner">${setupBlock()}${workTable(spec)}</div>`;
  const givens = { m: { value: m, unit: "kg" }, g: { value: G, unit: "m/s^2" }, F_A: { value: F, unit: "N" }, mu_s: { value: mus, unit: "" }, mu_k: { value: muk, unit: "" } };
  if (F2) givens.F_A2 = { value: F2, unit: "N" };
  return { html, statement, givens, spec, summary: `${ctx}, ${regime === "slide" ? "slides" : "stays at rest"}; μs ${fmt3(mus)}, μk ${fmt3(muk)}` };
}

/* ----- A2: proportional reasoning ----- */
function genA2(rng, variant) {
  if (variant === "data") {
    const mus = rng.uni(0.3, 0.7), ms = [10, 15, 20, 25], fs = ms.map(m => sf3(mus * m * G));
    const mNew = rng.pick([35, 40, 45, 50]);
    const surf = rng.pick(["a rubber mat", "a wooden floor", "a concrete floor"]);
    const statement = `A student uses a force sensor to measure the maximum static friction on boxes of different masses resting on ${surf}. Her data are shown in the table. Neglect drag.`;
    const tbl = `<table class="grid"><thead><tr><th>Mass (kg)</th>${ms.map(m => `<td>${fmt3(m)}</td>`).join("")}</tr></thead><tbody><tr><th>Max. static friction (N)</th>${fs.map(f => `<td>${fmt3(f)}</td>`).join("")}</tr></tbody></table>`;
    const muEff = fs[3] / (25 * G);
    const spec = [
      choice("a", "Which relationship best fits the data?", ["f ∝ m", "f ∝ m²", "f ∝ 1/m", "f ∝ √m"], "f ∝ m"),
      choice("b", "As the mass increases, the maximum static friction…", ["increases linearly", "increases nonlinearly", "decreases", "stays the same"], "increases linearly"),
      num("c", `Coefficient of static friction, ${MU_S}`, muEff, "", "f_25 / (m_25 * g)"),
      num("d", `Maximum static friction for a ${fmt3(mNew)} kg box`, muEff * mNew * G, "N", "{c} * m_new * g", ["c"]),
    ];
    withEq(spec, { c: `${SUB("μ", "s")} = ${SUB("f", "s,max")} / (mg)`, d: `${SUB("f", "s,max")} = ${SUB("μ", "s")}mg` });
    const html = `<div class="qbody"><div class="qtext"><p>${statement}</p>${tbl}</div></div>
      <div class="inner">${spec.slice(0, 2).map(p => mcBlock(p, "row")).join("")}${workTable(spec.filter(p => p.type === "num"))}</div>`;
    const givens = { m_25: { value: 25, unit: "kg" }, f_25: { value: fs[3], unit: "N" }, m_new: { value: mNew, unit: "kg" }, g: { value: G, unit: "m/s^2" } };
    return { html, statement: statement + ` Data (kg: N): ${ms.map((m, i) => `${m}: ${fs[i]}`).join(", ")}.`, givens, spec, summary: `data table, μs ≈ ${fmt3(muEff)}, predict ${mNew} kg` };
  }
  const k = rng.pick([0.5, 1 / 3, 2, 3]);
  const mu = rng.uni(0.45, 0.8);
  let statement, spec, givens, summary;
  if (variant === "mass") {
    let mA = sf3(rng.uni(k < 1 ? 70 : 30, k < 1 ? 96 : 45));
    const mB = sf3(mA * k);
    const fA = sf3(mu * mA * G), aA = sf3(fA / mA);
    statement = `Two bicyclists ride identical bicycles with identical tires on the same road. Bicyclist A has a total mass of ${fmt3(mA)} kg, and bicyclist B has a total mass of ${fmt3(mB)} kg. Both brake hard and skid. While skidding, bicyclist A experiences a friction force of ${fmt3(fA)} N and slows down at ${fmt3(aA)} m/s². Neglect drag.`;
    spec = [
      num("a", "Friction force on bicyclist B", fA * mB / mA, "N", "f_A * m_B / m_A"),
      num("b", "Magnitude of bicyclist B’s acceleration", fA / mA, "m/s²", "{a} / m_B", ["a"]),
      explain("c", "Explain your answer to (b) in terms of the forces on each bicyclist.", "Friction scales with mass (through N), so a = f/m is the same for both.",
        ["Friction is proportional to the normal force, which is proportional to mass", "B’s friction changes by the same factor as B’s mass", "So the acceleration (net force ÷ mass) is the same for both"],
        `B has ${fmtK(k)} the mass, so ${k < 1 ? "less" : "more"} normal force and ${fmtK(k)} the friction. Force and mass change by the same factor, so the acceleration is the same.`),
    ];
    withEq(spec, { a: `${SUB("f", "B")} = ${SUB("f", "A")}(${SUB("m", "B")}/${SUB("m", "A")})`, b: `${SUB("a", "B")} = ${SUB("f", "B")} / ${SUB("m", "B")}` });
    givens = { m_A: { value: mA, unit: "kg" }, m_B: { value: mB, unit: "kg" }, f_A: { value: fA, unit: "N" }, a_A: { value: aA, unit: "m/s^2" } };
    summary = `mass ×${fmt3(k)}: same a`;
  } else {
    const m = sf3(rng.uni(50, 95));
    const fA = sf3(mu * m * G), aA = sf3(fA / m);
    statement = `Two bicyclists of equal mass, ${fmt3(m)} kg each, ride identical bicycles on different roads. The coefficient of kinetic friction between bicyclist B’s tires and road is ${fmtK(k)} that between bicyclist A’s tires and road. Both brake hard and skid. While skidding, bicyclist A experiences a friction force of ${fmt3(fA)} N and slows down at ${fmt3(aA)} m/s². Neglect drag.`;
    spec = [
      num("a", "Friction force on bicyclist B", fA * k, "N", "k * f_A"),
      num("b", "Magnitude of bicyclist B’s acceleration", fA * k / m, "m/s²", "{a} / m", ["a"]),
      explain("c", "Explain your answer to (b) in terms of the forces on each bicyclist.", "Same N; friction changes with μ; same mass, so a changes by the same factor.",
        ["The normal force is the same because the masses are equal", "B’s friction changes by the same factor as μ", "With the same mass, the acceleration changes by that same factor"],
        `Their normal forces are equal, so B’s friction is ${fmtK(k)} A’s because of μ. With equal masses, B’s acceleration is also ${fmtK(k)} A’s.`),
    ];
    withEq(spec, { a: `${SUB("f", "B")} = k${SUB("f", "A")}`, b: `${SUB("a", "B")} = ${SUB("f", "B")} / m` });
    givens = { m: { value: m, unit: "kg" }, k: { value: r4(k), unit: "", note: "ratio stated in words" }, f_A: { value: fA, unit: "N" }, a_A: { value: aA, unit: "m/s^2" } };
    summary = `μ ×${fmt3(k)}: a ×${fmt3(k)}`;
  }
  const html = `<div class="qbody"><div class="qtext"><p>${statement}</p><p>Find (a) and (b), then answer (c).</p></div><div class="fig">${bikeSVG({ skid: true })}</div></div>
    <div class="inner">${workTable(spec)}${explainBlock(spec[2])}</div>`;
  return { html, statement, givens, spec, summary };
}

/* ----- B1: static or kinetic ----- */
const B1_POOL = [
  ["A box is pushed, but not hard enough to make it slide.", "Static"],
  ["A box slides across the floor while a student pushes it.", "Kinetic"],
  ["A ball rolls across the floor.", "Static"],
  ["A bicycle slows to a stop without its tires skidding.", "Static"],
  ["A car skids to a stop with its wheels locked.", "Kinetic"],
  ["A car speeds up from a stoplight without spinning its tires.", "Static"],
  ["A hockey puck slides across the ice.", "Kinetic"],
  ["A runner pushes off the track without slipping.", "Static"],
  ["A loaded sled is dragged across the snow.", "Kinetic"],
  ["A crate rides on the bed of a speeding-up truck without sliding.", "Static"],
  ["A person’s shoes slip on an icy sidewalk.", "Kinetic"],
  ["A book is pushed across a table at a constant speed.", "Kinetic"],
];
function genB1(rng, variant) {
  if (variant === "classify") {
    let picks;
    do { picks = rng.shuffle(B1_POOL.slice()).slice(0, 5); } while (picks.filter(p => p[1] === "Static").length < 2 || picks.filter(p => p[1] === "Kinetic").length < 2);
    const spec = picks.map(([txt, ans], i) => choice("abcde"[i], txt, ["Static", "Kinetic"], ans));
    const statement = "Classify the friction in each situation as static or kinetic. Assume anything that rolls does so without slipping unless stated otherwise.";
    const html = `<div class="qbody"><div class="qtext"><p>${statement}</p>${choiceRows(spec)}</div></div>`;
    return { html, statement, givens: {}, spec, summary: picks.map(p => p[1][0]).join("") };
  }
  const kinds = rng.shuffle(["correct", "nodrop", "linear", "tozero"]);
  const letters = ["A", "B", "C", "D"], ansLetter = letters[kinds.indexOf("correct")];
  const statement = "A student pushes horizontally on a heavy box that is resting on the floor, slowly increasing her push. Eventually the box starts to slide, and she keeps slowly increasing her push as it slides.";
  const spec = [
    choice("a", "While the box is still at rest, the friction on the box…", ["equals the maximum static friction", "equals the kinetic friction", "equals her applied force"], "equals her applied force"),
    choice("b", "The box starts to slide when her push…", ["exceeds the maximum static friction", "exceeds the kinetic friction", "equals the weight of the box"], "exceeds the maximum static friction"),
    choice("c", "While the box slides, the friction on the box…", ["equals the maximum static friction", "equals the kinetic friction", "equals her applied force"], "equals the kinetic friction"),
    choice("d", "Compared with just before the box starts to slide, the friction just after it starts to slide is…", ["greater", "less", "the same"], "less"),
    choice("e", "Which graph shows the friction on the box versus her applied force?", letters, ansLetter),
  ];
  const graphs = `<div class="mc" data-tag="e"><div class="mcq"><b>(e)</b> ${spec[4].prompt} ${tagSpan("e")}</div><div class="graphs">${kinds.map((k, i) => `<div>${miniGraphSVG(k)}${cbOpt(letters[i])}</div>`).join("")}</div></div>`;
  const html = `<div class="qbody"><div class="qtext"><p>${statement}</p></div><div class="fig">${sceneSVG("push", { w: 170, bw: 34, bh: 32 })}</div></div>
    <div class="inner">${spec.slice(0, 4).map(p => mcBlock(p, "row")).join("")}${graphs}</div>`;
  return { html, statement, givens: {}, spec, summary: `stages; graph ${ansLetter}` };
}

/* ----- C1: which coefficient can be found ----- */
function genC1(rng, variant) {
  const nums = () => { const m = sf3(rng.uni(10, 40)), F = sf3(rng.uni(60, 200)); return [m, F, sf3(F * rng.uni(0.6, 0.85))]; };
  const S = {}, T = {
    rest: ([m, F, F2]) => [`A ${fmt3(m)} kg box is at rest. A student pushes it horizontally with ${fmt3(F)} N, but the box does not slide.`, "Neither"],
    thresh: ([m, F, F2]) => [`A ${fmt3(m)} kg box stays at rest until a student’s horizontal push reaches ${fmt3(F)} N. Any larger push makes it slide.`, "Static only"],
    const: ([m, F, F2]) => [`A student pushes a ${fmt3(m)} kg box across the floor at a constant speed with a ${fmt3(F)} N horizontal force.`, "Kinetic only"],
    accel: ([m, F, F2]) => [`A student pushes a ${fmt3(m)} kg box with a ${fmt3(F)} N horizontal force, and the box speeds up. Its acceleration is not measured.`, "Neither"],
    both: ([m, F, F2]) => [`A ${fmt3(m)} kg box starts to slide when a student’s horizontal push exceeds ${fmt3(F)} N. Once it is moving, a ${fmt3(F2)} N push keeps it moving at a constant speed.`, "Both"],
  };
  for (const k in T) S[k] = T[k](nums());
  const sets = { v1: ["rest", "thresh", "const"], v2: ["thresh", "accel", "both"], v3: ["const", "rest", "both"], v4: ["accel", "const", "thresh"] };
  const keys = rng.shuffle(sets[variant].slice());
  const opts = ["Static only", "Kinetic only", "Both", "Neither"];
  const when = ["any time the box is sliding", "only while the box slides at a constant speed", "any time the box is not sliding", "only at the instant before the box starts to slide"];
  const spec = keys.map((k, i) => choice("abc"[i], S[k][0], opts, S[k][1]));
  spec.push(choice("d", "Her applied force equals the <b>kinetic</b> friction…", when, when[1]));
  spec.push(choice("e", "Her applied force equals the <b>maximum static</b> friction…", when, when[3]));
  const statement = "For (a)–(c), decide which coefficient(s) of friction between the box and the floor could be calculated from the information given. Neglect drag.";
  const html = `<div class="qbody"><div class="qtext"><p>${statement}</p></div></div>
    <div class="inner">${spec.slice(0, 3).map(p => mcBlock(p, "row")).join("")}<p style="margin:8px 0 2px">For (d) and (e), a student pushes a box horizontally across a floor.</p>${spec.slice(3).map(p => mcBlock(p, "col2")).join("")}</div>`;
  return { html, statement: statement + " " + keys.map((k, i) => `(${"abc"[i]}) ${S[k][0]}`).join(" "), givens: {}, spec, summary: keys.join(", ") };
}

/* ----- D1: net-force reasoning ----- */
function d1Item(rng, kind, t1, t2) {
  if (kind === "triple") {
    const a = sf3(rng.uni(2, 9)), k = rng.pick([2, 3]), ka = sf3(k * a), kw = { 2: "twice", 3: "three times" }[k];
    const text = `Two students push identical boxes across identical rough floors so that the boxes speed up. Student A’s box speeds up at ${fmt3(a)} m/s². Student B pushes ${kw} as hard as student A. Neglect drag.`;
    return { text, fig: "", parts: [
      choice(t1, "What is the acceleration of student B’s box?", ["It is impossible to tell without knowing the coefficient of friction", `Less than ${fmt3(ka)} m/s²`, `${fmt3(ka)} m/s²`, `More than ${fmt3(ka)} m/s²`], `More than ${fmt3(ka)} m/s²`),
      explain(t2, "Justify your answer.", "Friction is the same, so B’s net force is more than k times A’s.",
        ["Both boxes experience the same kinetic friction (same mass and surface)", `The net force is the push minus friction, so B’s net force is more than ${kw} A’s`, `With equal masses, B’s acceleration is more than ${kw} A’s`],
        `Friction is the same on both boxes. B’s push is ${kw} as big, but friction doesn’t change, so B’s net force is more than ${kw} A’s, and so is its acceleration.`)] };
  }
  if (kind === "photos") {
    const P = sf3(rng.uni(15, 60)), motion = rng.pick(["constant", "speeding", "slowing"]);
    const ans = { constant: `${fmt3(P)} N`, speeding: `Less than ${fmt3(P)} N`, slowing: `More than ${fmt3(P)} N` }[motion];
    const why = { constant: "Equal spacing means constant velocity, so the net force is zero and friction equals the push.",
      speeding: "Growing spacing means the box speeds up, so the net force points forward and friction is less than the push.",
      slowing: "Shrinking spacing means the box slows down, so the net force points backward and friction is more than the push." }[motion];
    const text = `A camera takes a photo every second while a student pushes a box to the right with a constant horizontal force of ${fmt3(P)} N. The photos are combined into the image shown. Neglect drag.`;
    return { text, fig: photoStripSVG(motion), motion, parts: [
      choice(t1, "What is the size of the friction force on the box?", ["0 N", `Less than ${fmt3(P)} N`, `${fmt3(P)} N`, `More than ${fmt3(P)} N`], ans),
      explain(t2, "Justify your answer using the photos.", why, [
        { constant: "The spacing between photos is equal, so the velocity is constant", speeding: "The spacing grows, so the box is speeding up", slowing: "The spacing shrinks, so the box is slowing down" }[motion],
        { constant: "Constant velocity means the net force is zero", speeding: "Speeding up means the net force points in the direction of motion", slowing: "Slowing down means the net force points opposite the motion" }[motion],
        { constant: "So the friction equals the push", speeding: "So the friction is less than the push", slowing: "So the friction is more than the push" }[motion]], why)] };
  }
  const accel = rng.next() < 0.5;
  const opts = accel
    ? ["Applied force and normal force", "Coefficient of static friction and mass", "Coefficient of kinetic friction and normal force", "Applied force, acceleration, and normal force"]
    : ["Applied force only", "Coefficient of static friction and normal force", "Coefficient of kinetic friction and mass", "Mass and speed"];
  const ans = accel ? [opts[2], opts[3]] : [opts[0], opts[2]];
  const text = `A student pushes horizontally on a box, and the box ${accel ? "speeds up" : "moves at a constant speed"} across the floor. Neglect drag.`;
  return { text, fig: "", parts: [
    multiChoice(t1, "Which two sets of information would let her find the friction force on the box?", opts, ans),
    explain(t2, "Explain how one of your choices gives the friction force.", accel ? "μk·N gives kinetic friction directly; or N gives the mass, then friction = push − ma." : "At constant speed the friction equals the push; or μk times mg gives the friction.",
      accel ? ["Kinetic friction equals μk times the normal force", "The normal force gives the mass (N = mg on a level floor)", "Friction = applied force − mass × acceleration"] : ["At constant speed the net force is zero, so friction equals the push", "Kinetic friction equals μk times the normal force (mg on a level floor)"],
      accel ? "Kinetic friction is μk times the normal force, so knowing both gives the friction directly." : "At constant speed the net force is zero, so the friction equals the applied force.")] };
}
function genD1(rng, variant) {
  const [k1, k2] = variant.split("+");
  const A = d1Item(rng, k1, "a", "b"), B = d1Item(rng, k2, "c", "d");
  const block = it => `<div class="qbody" style="margin-top:4px"><div class="qtext"><p>${it.text}</p></div></div>
    ${it.fig ? `<div class="fig" style="margin:2px 0 4px">${it.fig}</div>` : ""}
    ${mcBlock(it.parts[0], "col")}${explainBlock(it.parts[1])}`;
  const html = `<div class="inner">${block(A)}<div style="border-top:1px dotted #ccc;margin:6px 0"></div>${block(B)}</div>`;
  const spec = [...A.parts, ...B.parts];
  return { html, statement: `(a, b) ${A.text} (c, d) ${B.text}${A.motion || B.motion ? ` [photo spacing: ${A.motion || B.motion}]` : ""}`, givens: {}, spec, summary: variant + (A.motion || B.motion ? ` (${A.motion || B.motion})` : "") };
}

/* ----- D3: friction as the driving force ----- */
function genD3(rng, variant) {
  if (variant === "bike" || variant === "skid") {
    const skid = variant === "skid";
    const m = sf3(rng.uni(55, 90)), mus = sf3(rng.uni(0.55, 0.85)), muk = sf3(mus * rng.uni(0.65, 0.8)), D = sf3(rng.uni(20, 60));
    const N = m * G, f = (skid ? muk : mus) * N, net = f + D, a = net / m;
    const X = sf3(a * (rng.next() < 0.5 ? rng.uni(0.7, 0.85) : rng.uni(1.15, 1.3)));
    const statement = `A bicyclist is riding to the right and ${skid ? "slams on the brakes so hard that both tires skid" : "wants to stop as quickly as possible, so she squeezes the brakes as hard as she can <b>without</b> making the tires skid"}. The combined mass of the bicyclist and bicycle is ${fmt3(m)} kg. The coefficient of static friction between the tires and the road is ${MU_S} = ${fmt3(mus)}, the coefficient of kinetic friction is ${MU_K} = ${fmt3(muk)}, and she experiences a ${fmt3(D)} N drag force.`;
    const spec = [
      fbdPart([FRC("Weight", "W", "down"), FRC("Normal force", "N", "up"), FRC("Friction (road on tires)", "f", "left"), FRC("Drag", "D", "left")], `of the bicyclist while ${skid ? "skidding" : "braking"}`), GU,
      num("b", "Normal force, N", N, "N", "m * g"),
      choice("c", "Direction of the friction on the bicycle", ["Right", "Left"], "Left"),
      choice("d", "Type of friction", ["Static", "Kinetic"], skid ? "Kinetic" : "Static"),
      num("e", "Friction force", f, "N", `${skid ? "mu_k" : "mu_s"} * {b}`, ["b"], skid ? "kinetic" : "maximum static"),
      num("f", "Net force, |F<sub>net</sub>|", net, "N", "{e} + D", ["e"]),
      num("g", "Magnitude of her acceleration", a, "m/s²", "{f} / m", ["f"]),
      skid ? choice("h", "Could she stop in a shorter distance if her tires did not skid?", ["Yes", "No"], "Yes")
        : choice("h", `Could she slow down at ${fmt3(X)} m/s² without skidding?`, ["Yes", "No"], X <= a ? "Yes" : "No", "X <= {g}", ["g"]),
    ];
    withEq(spec, { b: "N = mg", e: `f = ${skid ? SUB("μ", "k") : SUB("μ", "s")}N`, f: `${SUB("F", "net")} = f + D`, g: `a = ${SUB("F", "net")} / m` });
    const html = `<div class="qbody"><div class="qtext"><p>${statement}</p><p>(a) Draw a free-body diagram of the bicyclist ${skid ? "while she skids" : "while she brakes as hard as possible without skidding"}. Then answer (b)–(h).</p></div><div class="fig">${bikeSVG({ skid })}</div></div>
      <div class="inner">${setupBlock()}${workTable(spec)}</div>`;
    const givens = { m: { value: m, unit: "kg" }, g: { value: G, unit: "m/s^2" }, mu_s: { value: mus, unit: "" }, mu_k: { value: muk, unit: "" }, D: { value: D, unit: "N" } };
    if (!skid) givens.X = { value: X, unit: "m/s^2" };
    return { html, statement, givens, spec, summary: `${skid ? "skidding" : "max braking, no skid"}; a = ${fmt3(a)} m/s²` };
  }
  const brake = variant === "truck-brake";
  const m = sf3(rng.uni(20, 90)), mus = sf3(rng.uni(0.3, 0.75)), muk = sf3(mus * rng.uni(0.65, 0.85));
  const N = m * G, f = mus * N, a = f / m;
  const X = sf3(a * (rng.next() < 0.5 ? rng.uni(0.6, 0.85) : rng.uni(1.15, 1.4)));
  const ok = X <= a, fdir = brake ? "Left" : "Right";
  const outcomes = ["The box stays in place on the truck bed", "The box slides toward the front of the truck", "The box slides toward the back of the truck"];
  const statement = `A ${fmt3(m)} kg box sits on the flat bed of a truck that is moving to the right. The coefficient of static friction between the box and the truck bed is ${MU_S} = ${fmt3(mus)}, and the coefficient of kinetic friction is ${MU_K} = ${fmt3(muk)}. The truck ${brake ? "slows down" : "speeds up"}. Answer (b)–(g) for the <b>largest ${brake ? "deceleration" : "acceleration"}</b> the truck can have without the box sliding. Neglect drag.`;
  const spec = [
    fbdPart([FRC("Weight", "W", "down"), FRC("Normal force", "N", "up"), FRC("Friction (truck bed on box)", "f", fdir.toLowerCase())], "of the box"), GU,
    num("b", "Normal force, N", N, "N", "m * g"),
    choice("c", "Direction of the friction on the box", ["Right", "Left"], fdir),
    choice("d", "Type of friction", ["Static", "Kinetic"], "Static"),
    num("e", "Friction force", f, "N", "mu_s * {b}", ["b"], "maximum static"),
    num("f", "Net force, |F<sub>net</sub>|", f, "N", "{e}", ["e"]),
    num("g", "Magnitude of the box’s acceleration", a, "m/s²", "{f} / m", ["f"]),
    choice("h", `What happens if the truck ${brake ? "slows down" : "speeds up"} at ${fmt3(X)} m/s²?`, outcomes, ok ? outcomes[0] : brake ? outcomes[1] : outcomes[2], "X <= {g} ? stays : slides", ["g"]),
  ];
  withEq(spec, { b: "N = mg", e: `${SUB("f", "s,max")} = ${SUB("μ", "s")}N`, f: `${SUB("F", "net")} = ${SUB("f", "s,max")}`, g: `a = ${SUB("F", "net")} / m` });
  const html = `<div class="qbody"><div class="qtext"><p>${statement}</p><p>(a) Draw a free-body diagram of the box. Then answer (b)–(h).</p></div><div class="fig">${truckSVG()}</div></div>
    <div class="inner">${setupBlock()}${workTable(spec)}</div>`;
  const givens = { m: { value: m, unit: "kg" }, g: { value: G, unit: "m/s^2" }, mu_s: { value: mus, unit: "" }, mu_k: { value: muk, unit: "" }, X: { value: X, unit: "m/s^2" } };
  return { html, statement, givens, spec, summary: `truck ${brake ? "braking" : "speeding up"}; a max = ${fmt3(a)} m/s², test ${fmt3(X)} → ${ok ? "stays" : "slides"}` };
}

/* ----- D4: opposing forces ----- */
function genD4(rng, variant) {
  const m = sf3(rng.uni(20, 50)), mus = sf3(rng.uni(0.3, 0.55)), muk = sf3(mus * rng.uni(0.65, 0.85));
  const N = m * G, fs = mus * N, fk = muk * N;
  const TR = sf3(fs * rng.uni(1.9, 2.4));
  const diffs = [rng.uni(1.2, 1.5), rng.uni(0.2, 0.75), -rng.uni(0.2, 0.75), -rng.uni(1.2, 1.5)].map(x => x * fs);
  if (rng.next() < 0.3) diffs[rng.pick([1, 2])] = 0;
  const TLs = diffs.map(d => d === 0 ? TR : sf3(TR - d)).sort((x, y) => x - y);
  const who = variant === "movers" ? ["Two movers pull on a", "crate", "mover"] : ["Two students pull on a", "block", "student"];
  const statement = `${who[0]} ${fmt3(m)} kg ${who[1]} resting on a level floor, using horizontal ropes. The ${who[2]} on the right pulls with a constant tension T<sub>R</sub> = ${fmt3(TR)} N. The ${who[2]} on the left pulls with the tension T<sub>L</sub> given in each row. Each row is a separate trial that starts with the ${who[1]} at rest. The coefficient of static friction is ${MU_S} = ${fmt3(mus)}, and the coefficient of kinetic friction is ${MU_K} = ${fmt3(muk)}. Neglect drag.`;
  const spec = [
    num("a", "Normal force, N", N, "N", "m * g"),
    num("b", "Maximum static friction, f<sub>s,max</sub>", fs, "N", "mu_s * {a}", ["a"]),
    num("c", "Kinetic friction, f<sub>k</sub>", fk, "N", "mu_k * {a}", ["a"]),
  ];
  withEq(spec, { a: "N = mg", b: `${SUB("f", "s,max")} = ${SUB("μ", "s")}N`, c: `${SUB("f", "k")} = ${SUB("μ", "k")}N` });
  let rows = "";
  TLs.forEach((TL, i) => {
    const d = TR - TL, slides = Math.abs(d) > fs;
    const sl = slides ? (d > 0 ? "Yes, right" : "Yes, left") : "No";
    const fr = slides ? fk : Math.abs(d), net = slides ? Math.abs(d) - fk : 0;
    const dir = d === 0 ? "Neither" : d > 0 ? "Left" : "Right";
    const t = `d${i + 1}`;
    spec.push({ tag: t, type: "trow", TL, deps: ["b", "c"], pts: { slides: 1, friction: 1, friction_direction: 1, net_force: 1 },
      cells: { slides: sl, friction: fr, friction_direction: dir, net_force: net },
      expr: { slides: "|T_R - T_L| > {b} ? (T_R > T_L ? 'Yes, right' : 'Yes, left') : 'No'", friction: "slides ? {c} : |T_R - T_L|", friction_direction: "opposite the direction of T_R - T_L (Neither if zero)", net_force: "slides ? |T_R - T_L| - {c} : 0" } });
    const stack = o => `<div class="stack">${o.map(cbOpt).join("")}</div>`;
    rows += `<tr data-tag="${t}"><td>${tagSpan(t)}</td><td>${fmt3(TL)}</td><td class="c-s">${stack(["Yes, right", "Yes, left", "No"])}</td><td class="c-f"></td><td class="c-d">${stack(["Right", "Left", "Neither"])}</td><td class="c-n"></td></tr>`;
  });
  const html = `<div class="qbody"><div class="qtext"><p>${statement}</p><p>Find (a)–(c), then complete the table (d1–d4).</p></div><div class="fig">${tugSVG()}</div></div>
    <div class="inner">${workTable(spec)}
      <table class="grid tall"><thead><tr><th>Row</th><th>T<sub>L</sub> (N)</th><th>Slides?</th><th>Friction (N)</th><th>Friction direction</th><th>|F<sub>net</sub>| (N)</th></tr></thead><tbody>${rows}</tbody></table></div>`;
  const givens = { m: { value: m, unit: "kg" }, g: { value: G, unit: "m/s^2" }, mu_s: { value: mus, unit: "" }, mu_k: { value: muk, unit: "" }, T_R: { value: TR, unit: "N" } };
  return { html, statement, givens, spec, summary: `T_R ${fmt3(TR)} N, f_s,max ${fmt3(fs)} N` };
}

/* ----- E1: skidding to a stop ----- */
function genE1(rng, variant) {
  const forces = [FRC("Weight", "W", "down"), FRC("Normal force", "N", "up"), FRC("Friction", "f", "left")];
  if (variant === "graph") {
    let v0, t, a;
    do { v0 = rng.pick([6, 8, 10, 12, 14, 16]); t = rng.pick([1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6]); a = v0 / t; } while (a < 1.2 || a > 7.5);
    const m = sf3(rng.uni(5, 40)), N = m * G, f = m * a;
    const statement = `A ${fmt3(m)} kg box is given a push to the right and then slides across a level floor until it stops. The graph shows the box’s velocity after the push ends. Neglect drag.`;
    const spec = [
      fbdPart(forces, "of the box while it slides"), GU,
      choice("b", "Type of friction while the box slides", ["Static", "Kinetic"], "Kinetic"),
      num("c", "Magnitude of the box’s acceleration", a, "m/s²", "v_0 / t_stop", [], "slope of graph"),
      num("d", "Net force, |F<sub>net</sub>|", f, "N", "m * {c}", ["c"]),
      num("e", "Normal force, N", N, "N", "m * g"),
      num("f", "Friction force", f, "N", "{d}", ["d"]),
      num("g", `Coefficient of kinetic friction, ${MU_K}`, a / G, "", "{f} / {e}", ["f", "e"]),
    ];
    withEq(spec, { c: "a = Δv / Δt", d: `${SUB("F", "net")} = ma`, e: "N = mg", f: `${SUB("f", "k")} = ${SUB("F", "net")}`, g: `${SUB("μ", "k")} = ${SUB("f", "k")} / N` });
    const html = `<div class="qbody"><div class="qtext"><p>${statement}</p><p>(a) Draw a free-body diagram of the box while it slides. Then answer (b)–(g).</p></div></div>
      <div class="inner">${setupBlock(vtGraphSVG(v0, t))}${workTable(spec)}</div>`;
    const givens = { m: { value: m, unit: "kg" }, g: { value: G, unit: "m/s^2" }, v_0: { value: v0, unit: "m/s", note: "read from graph" }, t_stop: { value: t, unit: "s", note: "read from graph" } };
    return { html, statement, givens, spec, summary: `v–t graph: ${v0} m/s stops at ${t} s` };
  }
  const m = sf3(rng.uni(55, 95)), v0 = sf3(rng.uni(6, 14)), muk = sf3(rng.uni(0.4, 0.75));
  const N = m * G, f = muk * N, a = f / m, dx = v0 * v0 / (2 * a);
  if (variant === "distance") {
    const statement = `A bicyclist riding to the right at ${fmt3(v0)} m/s locks her brakes and skids to a stop on a level road. The combined mass of the bicyclist and bicycle is ${fmt3(m)} kg, and the coefficient of kinetic friction between the tires and the road is ${MU_K} = ${fmt3(muk)}. Neglect drag.`;
    const spec = [
      fbdPart(forces, "of the bicyclist while skidding"), GU,
      choice("b", "Type of friction while she skids", ["Static", "Kinetic"], "Kinetic"),
      num("c", "Normal force, N", N, "N", "m * g"),
      num("d", "Friction force", f, "N", "mu_k * {c}", ["c"]),
      num("e", "Magnitude of her acceleration", a, "m/s²", "{d} / m", ["d"]),
      num("f", "Stopping distance", dx, "m", "v_0 * v_0 / (2 * {e})", ["e"]),
      num("g", "Stopping time", v0 / a, "s", "v_0 / {e}", ["e"]),
    ];
    withEq(spec, { c: "N = mg", d: `${SUB("f", "k")} = ${SUB("μ", "k")}N`, e: `a = ${SUB("f", "k")} / m`, f: `Δx = ${SUB("v", "0")}² / (2a)`, g: `t = ${SUB("v", "0")} / a` });
    const html = `<div class="qbody"><div class="qtext"><p>${statement}</p><p>(a) Draw a free-body diagram of the bicyclist while she skids. Then answer (b)–(g).</p></div><div class="fig">${bikeSVG({ skid: true })}</div></div>
      <div class="inner">${setupBlock()}${workTable(spec)}</div>`;
    const givens = { m: { value: m, unit: "kg" }, g: { value: G, unit: "m/s^2" }, v_0: { value: v0, unit: "m/s" }, mu_k: { value: muk, unit: "" } };
    return { html, statement, givens, spec, summary: `skid from ${fmt3(v0)} m/s, Δx = ${fmt3(dx)} m` };
  }
  const d = sf3(dx);
  const aR = v0 * v0 / (2 * d);
  const statement = `After a bicycle accident, investigators measure skid marks ${fmt3(d)} m long on a level road. The bicyclist was riding at ${fmt3(v0)} m/s when the tires locked, and she skidded to a stop. The combined mass of the bicyclist and bicycle is ${fmt3(m)} kg. Neglect drag.`;
  const spec = [
    fbdPart(forces, "of the bicyclist while skidding"), GU,
    choice("b", "Type of friction while she skids", ["Static", "Kinetic"], "Kinetic"),
    num("c", "Magnitude of her acceleration", aR, "m/s²", "v_0 * v_0 / (2 * dx)"),
    num("d", "Net force, |F<sub>net</sub>|", m * aR, "N", "m * {c}", ["c"]),
    num("e", "Normal force, N", N, "N", "m * g"),
    num("f", "Friction force", m * aR, "N", "{d}", ["d"]),
    num("g", `Coefficient of kinetic friction, ${MU_K}`, m * aR / N, "", "{f} / {e}", ["f", "e"]),
  ];
  withEq(spec, { c: `a = ${SUB("v", "0")}² / (2Δx)`, d: `${SUB("F", "net")} = ma`, e: "N = mg", f: `${SUB("f", "k")} = ${SUB("F", "net")}`, g: `${SUB("μ", "k")} = ${SUB("f", "k")} / N` });
  const html = `<div class="qbody"><div class="qtext"><p>${statement}</p><p>(a) Draw a free-body diagram of the bicyclist while she skids. Then answer (b)–(g).</p></div><div class="fig">${bikeSVG({ skid: true })}</div></div>
    <div class="inner">${setupBlock()}${workTable(spec)}</div>`;
  const givens = { m: { value: m, unit: "kg" }, g: { value: G, unit: "m/s^2" }, v_0: { value: v0, unit: "m/s" }, dx: { value: d, unit: "m" } };
  return { html, statement, givens, spec, summary: `skid marks ${fmt3(d)} m from ${fmt3(v0)} m/s → μk ${fmt3(m * aR / N)}` };
}

const groups = [
  { id: "A1", tier: 1, version: 1, minutes: 4, objective: "Explain how mass and surface affect the normal force, the coefficient of friction, and the friction force.", title: "Compare N, μ, and f", desc: "Two cases differ in mass or surface", def: 1,
    variants: ["mass-A", "mass-B", "surface-A", "surface-B"], gen: genA1, lessons: [["7.3", "Vocabulary and Concepts", "#11, #12"], ["7.2", "Inquiry", "Maximum Friction Force"]],
    vlabels: { "mass-A": "Different masses (A heavier)", "mass-B": "Different masses (B heavier)", "surface-A": "Different surfaces (A rough)", "surface-B": "Different surfaces (B rough)" } },
  { id: "A2", tier: 2, version: 1, minutes: 7, objective: "Use proportional reasoning to predict how friction and acceleration change when mass or μ changes, and identify a proportional relationship from data.", title: "Proportional reasoning", desc: "Scale mass or μ; predict f and a", def: 0,
    variants: ["mass", "mu", "data"], gen: genA2, lessons: [["7.8", "Multiple Choice Challenge", "#1, #2"], ["7.2", "Inquiry", "Friction Force & Mass"]],
    vlabels: { mass: "Different masses", mu: "Different μ", data: "Data table" } },
  { id: "B1", tier: 1, version: 1, minutes: 4, objective: "Distinguish static from kinetic friction and describe how friction responds as an applied force increases.", title: "Static or kinetic?", desc: "Classify situations; friction graph shape", def: 0,
    variants: ["classify", "stages"], gen: genB1, lessons: [["7.3", "Vocabulary and Concepts", "#13, #15"], ["7.8", "Multiple Choice Challenge", "#8"], ["7.2", "Inquiry", "Friction & Applied Force"]],
    vlabels: { classify: "Classify situations", stages: "Stages of a push + graph" } },
  { id: "B2", tier: 2, version: 1, minutes: 9, objective: "Decide whether an object slides and find the friction and net force for a range of applied forces.", title: "Slide-or-not table", desc: "Increasing push; f and F_net for each", def: 1,
    variants: ["push", "rope"], gen: genB2, lessons: [["7.4", "Free-Body Diagram Analysis", "#1, #2"], ["7.2", "Inquiry", "Friction & Applied Force"]],
    vlabels: { push: "Pushed box", rope: "Crate pulled by rope" } },
  { id: "C1", tier: 1, version: 1, minutes: 4, objective: "Identify which coefficient of friction a measurement can determine, and at what moment.", title: "Which μ can be found?", desc: "Conditions for measuring μs and μk", def: 0,
    variants: ["v1", "v2", "v3", "v4"], gen: genC1, lessons: [["7.3", "Vocabulary and Concepts", "#14"], ["7.8", "Multiple Choice Challenge", "#5"]],
    vlabels: { v1: "Scenario set 1", v2: "Scenario set 2", v3: "Scenario set 3", v4: "Scenario set 4" } },
  { id: "C2", tier: 2, version: 1, minutes: 8, objective: "Calculate μs and μk from threshold and constant-speed forces or from a force–time graph.", title: "Measure μs and μk", desc: "From forces or a force–time graph", def: 1,
    variants: ["threshold", "graph"], gen: genC2, lessons: [["7.6", "Complete Problems 2", "#1, #2"], ["7.8", "Multiple Choice Challenge", "#6, #7"]],
    vlabels: { threshold: "From measured forces", graph: "From a force–time graph" } },
  { id: "D1", tier: 2, version: 1, minutes: 7, objective: "Reason about net force with friction in multiple-choice situations and justify the choice.", title: "Net-force reasoning", desc: "Multiple choice with justification", def: 0,
    variants: ["triple+photos", "photos+info", "info+triple"], gen: genD1, lessons: [["7.8", "Multiple Choice Challenge", "#3, #4, #11"]],
    vlabels: { "triple+photos": "Bigger push + photo strip", "photos+info": "Photo strip + which info", "info+triple": "Which info + bigger push" } },
  { id: "D2", tier: 2, version: 1, minutes: 9, objective: "Solve a complete friction problem: decide whether the object slides, then find friction, net force, and acceleration.", title: "Pushed box: complete problem", desc: "Does it slide? Then f, F_net, a", def: 1,
    variants: ["push-slide", "push-rest", "rope-slide", "rope-rest", "sled-slide", "sled-rest"], gen: genD2, lessons: [["7.5", "Complete Problems 1", "#1"]],
    vlabels: { "push-slide": "Push, slides", "push-rest": "Push, stays at rest", "rope-slide": "Rope, slides", "rope-rest": "Rope, stays at rest", "sled-slide": "Sled, slides", "sled-rest": "Sled, stays at rest" },
    arrange: rng => {
      const ctx = rng.shuffle(["push", "rope", "sled"]); const r0 = rng.next() < .5 ? ["slide", "rest"] : ["rest", "slide"];
      return [0, 1, 2, 3, 4, 5].map(i => `${ctx[i % 3]}-${r0[i % 2]}`);
    } },
  { id: "D3", tier: 3, version: 1, minutes: 12, objective: "Apply friction as the force that stops or accelerates an object, using the maximum static friction as a limit.", title: "Friction as the driving force", desc: "Max braking with drag; box on a truck", def: 0,
    variants: ["bike", "skid", "truck-accel", "truck-brake"], gen: genD3, lessons: [["7.5", "Complete Problems 1", "#2, #3"]],
    vlabels: { bike: "Braking, no skid", skid: "Braking, skidding", "truck-accel": "Truck speeding up", "truck-brake": "Truck slowing down" } },
  { id: "D4", tier: 3, version: 1, minutes: 12, objective: "Determine whether an object slides, and the direction of friction, when opposing forces act.", title: "Opposing forces", desc: "Friction direction changes", def: 0,
    variants: ["students", "movers"], gen: genD4, lessons: [["7.7", "Challenge", "#1"]],
    vlabels: { students: "Two students, block", movers: "Two movers, crate" } },
  { id: "E1", tier: 3, version: 1, minutes: 11, objective: "Connect kinetic friction to stopping motion using Newton’s second law and kinematics.", tags: ['kinematics'], title: "Skidding to a stop", desc: "μk, a, and kinematics", def: 0,
    variants: ["distance", "marks", "graph"], gen: genE1, lessons: [["7.8", "Multiple Choice Challenge", "#9"], ["7.1", "Review", "#1"]],
    vlabels: { distance: "Find stopping distance", marks: "Find μk from skid marks", graph: "Find μk from a v–t graph" } },
];

QB.registerUnit({
  id: "U7", number: 7, title: "Friction", version: "1.0",
  source: "+Physics Unit 7",
  lessons: {
    "7.1": "Review", "7.2": "Inquiry", "7.3": "Vocabulary and Concepts", "7.4": "Free-Body Diagram Analysis",
    "7.5": "Complete Problems 1", "7.6": "Complete Problems 2", "7.7": "Challenge", "7.8": "Multiple Choice Challenge",
  },
  groups,
});
})();
