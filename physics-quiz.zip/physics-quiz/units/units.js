/* =====================================================================
   units/units.js: the list of units the app loads, in course order.
   To add a unit, put its file in this folder and add its name below.
   (index.html, test.html and tools/build.py all read this list.)
   ===================================================================== */
const UNIT_FILES = [
  "unit-06-forces.js",
  "unit-07-friction.js",
];
for (const f of UNIT_FILES) document.write(`<script src="units/${f}"><\/script>`);
