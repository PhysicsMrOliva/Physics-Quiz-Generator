/* =====================================================================
   tools/test-runner.js: checks every question group in every unit.
   Open test.html in a browser. Run it after adding or changing a group.
   ===================================================================== */
"use strict";
(function runTests() {
  const N = 200;                      // random number sets per version
  const rows = [], add = (who, status, details) => rows.push({ who, status, details });
  const pageBody = (() => { // usable height of a continuation page, in px
    const m = document.getElementById("measure");
    m.innerHTML = `<div class="page"><div class="qhead2">x</div><div class="page-body"></div><div class="page-foot">x</div></div>`;
    const h = m.querySelector(".page-body").clientHeight; m.innerHTML = ""; return h;
  })();
  // Course-level checks
  for (const p of QB.course.presets) for (const it of p.items)
    if (!QB.byUid[it.group]) add(`course.js preset “${p.name}”`, "bad", `uses ${it.group}, which doesn’t exist`);
  for (const g of QB.groups) {
    const problems = [], warnings = [];
    const need = { tier: [1, 2, 3].includes(g.tier), minutes: g.minutes > 0, objective: !!g.objective, version: Number.isInteger(g.version),
      lessons: Array.isArray(g.lessons) && g.lessons.length > 0, variants: Array.isArray(g.variants) && g.variants.length > 0, gen: typeof g.gen === "function" };
    for (const [k, ok] of Object.entries(need)) if (!ok) problems.push(`missing or invalid “${k}”`);
    if (!need.gen || !need.variants) { add(g.uid, "bad", problems.join("; ")); continue; }
    let maxH = 0, pts = new Set();
    for (const v of g.variants) {
      for (let i = 0; i < N && problems.length < 6; i++) {
        let q;
        try { q = g.gen(makeRng(`test|${g.uid}|${v}|${i}`), v); } catch (e) { problems.push(`${v} #${i}: ${e.message}`); break; }
        for (const k of ["html", "statement", "givens", "spec", "summary"]) if (q[k] === undefined) problems.push(`${v}: result has no “${k}”`);
        const tags = q.spec.map(p => p.tag);
        if (new Set(tags).size !== tags.length) problems.push(`${v}: duplicate part tags`);
        for (const p of q.spec) {
          if (p.type === "num" && (!isFinite(p.value) || p.value < 0)) problems.push(`${v} #${i}: part ${p.tag} = ${p.value}`);
          if (p.type === "num" && !p.expr) problems.push(`${v}: part ${p.tag} has no expr`);
          if (p.type === "choice" && ![].concat(p.answer).every(a => p.options.includes(a))) problems.push(`${v} #${i}: part ${p.tag} answer not among options`);
          for (const d of p.deps || []) if (!tags.includes(d)) problems.push(`${v}: part ${p.tag} depends on missing part ${d}`);
        }
        if (/NaN|undefined|Infinity/.test(q.html)) problems.push(`${v} #${i}: NaN/undefined in question`);
        if (i === 0) {
          const again = g.gen(makeRng(`test|${g.uid}|${v}|0`), v);
          if (again.html !== q.html) problems.push(`${v}: same seed gave different output (not reproducible)`);
          // course rule: no equations in question text (heuristic: symbol = symbol)
          const txt = plain(q.statement + " " + q.spec.map(p => p.prompt || "").join(" "));
          const eq = txt.match(/(?:^|[\s(])[A-Za-zμΔ][\w,]*\s*=\s*[A-Za-zμΔ(]/);
          if (eq) warnings.push(`${v}: possible equation in question text near “${eq[0].trim()}”`);
          const m = document.getElementById("measure");
          m.innerHTML = `<div class="page"><div class="page-body"><div class="q"><div class="gut"><b>1</b></div>${q.html}</div></div></div>`;
          maxH = Math.max(maxH, m.querySelector(".q").offsetHeight);
          pts.add(q.spec.reduce((a, p) => a + ptsOf(p), 0));
        }
      }
    }
    if (maxH > pageBody) problems.push(`tallest version is ${maxH}px, taller than a page (${pageBody}px)`);
    const info = `${g.variants.length} versions × ${N} number sets; tallest ${maxH}px of ${pageBody}px; points ${[...pts].join("/")}`;
    add(g.uid, problems.length ? "bad" : warnings.length ? "warnc" : "ok", [...problems, ...warnings, info].join("<br>"));
  }
  const bad = rows.filter(r => r.status === "bad").length, warn = rows.filter(r => r.status === "warnc").length;
  document.getElementById("sum").textContent = `${QB.units.length} unit(s), ${QB.groups.length} groups: ${bad ? `${bad} failing` : "all passing"}${warn ? `, ${warn} with warnings` : ""}. Engine ${QB.ENGINE_VERSION}.`;
  document.getElementById("rows").innerHTML = rows.map(r => `<tr><td>${r.who}</td><td class="${r.status}">${{ ok: "Pass", bad: "Fail", warnc: "Check" }[r.status]}</td><td>${r.details}</td></tr>`).join("");
  window.TEST_RESULT = { bad, warn, rows };
})();
