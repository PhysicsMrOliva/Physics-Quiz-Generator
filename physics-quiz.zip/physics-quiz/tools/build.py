#!/usr/bin/env python3
"""Bundle the multi-file project into one self-contained HTML file.

Usage (from the project folder):   python3 tools/build.py
Output:                            dist/quiz-generator.html

The single file works offline and can be emailed or opened anywhere.
Day-to-day you can also just open index.html directly; building is optional.
"""
import pathlib, re, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent

def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")

def inline_script(code, label):
    code = code.replace("</script", "<\\/script")
    return f"<script>/* ---- {label} ---- */\n{code}\n</script>"

def unit_files():
    manifest = read("units/units.js")
    block = re.search(r"UNIT_FILES\s*=\s*\[(.*?)\]", manifest, re.S)
    if not block:
        sys.exit("Could not find UNIT_FILES in units/units.js")
    return re.findall(r'"([^"]+\.js)"', block.group(1))

def main():
    html = read("index.html")
    html = html.replace('<link rel="stylesheet" href="styles.css">', "<style>\n" + read("styles.css") + "</style>")
    def repl(m):
        src = m.group(1)
        if src == "units/units.js":
            return "\n".join(inline_script(read(f"units/{f}"), f"units/{f}") for f in unit_files())
        return inline_script(read(src), src)
    html = re.sub(r'<script src="([^"]+)"></script>', repl, html)
    out = ROOT / "dist" / "quiz-generator.html"
    out.parent.mkdir(exist_ok=True)
    out.write_text(html, encoding="utf-8")
    print(f"Built {out.relative_to(ROOT)} ({out.stat().st_size // 1024} KB) with units: {', '.join(unit_files())}")

if __name__ == "__main__":
    main()
